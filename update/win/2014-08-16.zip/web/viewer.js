/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */
/* Copyright 2012 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/* globals PDFJS, PDFBug, FirefoxCom, Stats, Cache, PDFFindBar, CustomStyle,
           PDFFindController, ProgressBar, TextLayerBuilder, DownloadManager,
           getFileName, scrollIntoView, getPDFFileNameFromURL, PDFHistory,
           Preferences, SidebarView, ViewHistory, PageView, ThumbnailView, URL,
           noContextMenuHandler, SecondaryToolbar, PasswordPrompt,
           PresentationMode, HandTool, Promise, DocumentProperties,
           DocumentOutlineView, DocumentAttachmentsView, OverlayManager */

'use strict';
var book_id,title_book;
var cover_book="";
var tmp = window.location.href.split('&cov=');
//console.log(tmp)
cover_book = tmp[1];
//console.log(cover_book);
var loc = tmp[0].split('#');
//console.log(loc);
//var loc = window.location.href.split('#');
var buku = loc[1].split('_');
book_id = buku[buku.length-2];

if (navigator.appVersion.indexOf("Win")!=-1){
  //loc[1] = loc[1].replace('file:///','');
  loc[1] = 'file:///'+loc[1].replace('^^^','%20');
}else{
    
}

function back_to(){
  window.location.href="../index.html#/reader";
  var back = window.localStorage.getItem('back');
  setTimeout(function(){
    $('#_back').attr('onclick',back);
    setTimeout(function(){
        $('#_back').click();
    },500);
  },300);
}

alert("Unsupported Format to Open File");
back_to();
