var page_feeds=2;
var count_feed=0;
function show_feeds(){
    history.push('$("#feeds").click()');
    var notes;
    var local = ReadData('_feed');
    if(local!=null){
      //console.log(local);
      $('#result_feeds').html("");
      parse_feed(local);
    }else{
        var before =$('#result_feeds').append('<center style="padding-top:25px;" class="loader"><img src="css/plugin/images/bx_loader.gif"></center>');
    }
    var token = window.localStorage.getItem('token');
    //notes = new majax('feeds/index',{'access_token':token,'per_page':10},'');
    notes = new majax_fast('feeds',{'access_token':token,'per_page':10},'');
    page_feeds =2;
    feeds_text ='';
    notes.success(function(data){
        //console.log(data)
        $('.loader').html('');
        if(data.meta.code==200){
            console.log(page_feeds);
            if(data.data.num_pages!=undefined){
                count_feed = data.data.num_pages;
                if(page_feeds<=data.data.num_pages){
                    $('#feed_more').css('visibility','visible');
                }else{
                    $('#feed_more').css('visibility','hidden');
                    $('.loader').html('');
                }
                //console.log(data.data.total_result,data.data.current_page_result)
                if(data.data.total_result>20){
                    $('#feed_more').css('visibility','visible');
                }else{
                    $('#feed_more').css('visibility','hidden');
                    $('.loader').html('');
                }
                
                WriteData('_feed', data)
                if(local==null){
                    $('#result_feeds').html("");
                  //console.log(local);
                    parse_feed(data);
                    setTimeout(function(){
                        ThisAnim('#result_feeds','fadeInRight');
                    },200);
                }else{
                    $('#result_feeds').html("");
                    parse_feed(data);
                }

                
                feeds_text +='<div style="padding-bottom:10px;display:none;"><div class="divider" style="padding-top:0px;"></div></div>';
            }else{
                //$('#result_feeds').append(data.data);
                $('#lr_reading').append('<center style="color:#ddd;padding-top:50px;">'+data.data+'</center>');
                $('.loader').html('');
            }
            
            
            //$('#result_feeds').html(feeds_text); 

            
            $('.loader').html('');
        }else{
            //alert('Network Error');
            // Moco.content="No Internet Connection";
            // $('#confirm_trans_failed').click();
            $('#result_feeds').append('<center style="color:#ddd;padding-top:50px;">No Activity</center>');
            //$('#result_feeds').append(data.data);
            $('.loader').html('');
            $('#feed_more').css('visibility','hidden');
            $('.loader').html('');
        }
    }),
    notes.error(function(data){
        //alert('Network Error');

        // Moco.content="No Internet Connection";
        // $('#confirm_trans_failed').click();
        
        //goto_current();
        //$('.loader').html('');
    });
}

function more_feed(){
    var before = $('#moco-load').addClass('fa fa-spinner fa-spin fa-large'); 
        before += $('#feed_action_more').attr('disabled','disabled')
    if(page_feeds<=count_feed){
        var notes;
        //var before =$('#result_feeds').append('<center style="padding-top:25px;" class="loader"><img src="css/plugin/images/bx_loader.gif"></center>');
        var token = window.localStorage.getItem('token');
        //notes = new majax('feeds/index',{'access_token':token,'per_page':10,'page':page_feeds},'');
        notes = new majax_fast('feeds',{'access_token':token,'per_page':10,'page':page_feeds},before);
        //page_feeds =2;
        feeds_text ='';
        notes.success(function(data){
            $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
            $('#feed_action_more').removeAttr('disabled')
            if(data.meta.code==200){
                page_feeds++
                console.log(page_feeds);
                if(data.data.num_pages!=undefined){
                    //count_feed = data.data.num_pages;
                    if(data.data.current_page_result<10){
                        $('#feed_more').css('visibility','hidden');
                    }else{
                        $('#feed_more').css('visibility','visibility');
                        $('.loader').html('');
                    }
                    //console.log(data.data.total_result,data.data.current_page_result)

                    //$('#result_feeds').html("");
                    parse_feed(data);
                    feeds_text +='<div style="padding-bottom:10px;display:none;"><div class="divider" style="padding-top:0px;"></div></div>';
                }else{
                    //$('#result_feeds').append(data.data);
                    $('#lr_reading').append('<center style="color:#ddd;padding-top:50px;">'+data.data+'</center>');
                    $('.loader').html('');
                }
                
                
                //$('#result_feeds').html(feeds_text); 


                $('.loader').html('');
            }else{
                $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
                $('#feed_action_more').removeAttr('disabled')
                //alert('Network Error');
                // Moco.content="No Internet Connection";
                // $('#confirm_trans_failed').click();
                $('#result_feeds').append('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
                //$('#result_feeds').append(data.data);
                $('.loader').html('');
                $('#feed_more').css('visibility','hidden');
                $('.loader').html('');
            }
        }),
        notes.error(function(data){
            $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
            $('#feed_action_more').removeAttr('disabled')
            //alert('Network Error');
            // Moco.content="No Internet Connection";
            // $('#confirm_trans_failed').click();
            //goto_current();
            //$('.loader').html('');
        });
    }else{
        $('#feed_more').css('visibility','hidden');
    }
}

function parse_feed(data){
    var feeds_text='';
    $.each(data.data.data,function(){
        var Feed = this.Feed;
        var Sender = this.Sender;
        var Object = this.Object;
        //console.log(Sender)
        //if(Feed.action_type=="JOIN"){
        if(Feed.sender_type=="User"){
            name_sender = Sender.User.name;
            //link_avatar = "user_details("+Sender.User.id+")";
            //link_avatar = "n_user("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"',1)";
            link_avatar = "n_user("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"',1,undefined,'"+Sender.User.name.replace(/ /g,'_')+"','"+Sender.User.avatar+"')";
            if(Sender.User.avatar){
                image=Sender.User.avatar;
            }else{
                image="images/icon/avatar.png";
            }
            if(Sender.Badge){
                cat_sender = Sender.Badge.name;
            }else{
                cat_sender = Sender.User.type
            }
        }else if(Feed.sender_type=="Author"){
            name_sender = Sender.Author.name;
            link_avatar = "n_author("+Sender.Author.id+",'"+Sender.Author.name.replace(/ /g,'_')+"',1)";   
            //link_avatar = "authors_details("+Sender.Author.id+")";
            if(Sender.Author.avatar){
                image=Sender.Author.avatar;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = 'Author';
        }else if(Feed.sender_type=="Library"){
            name_sender = Sender.Library.name;
            link_avatar = "n_pustaka("+Sender.Library.id+",'"+Sender.Library.name.replace(/ /g,'_')+"',1)"
            //link_avatar = "pustaka("+Sender.Library.id+")";
            if(Sender.Library.logo){
                image=Sender.Library.logo;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = "Library";
        }else if(Feed.sender_type=="Store"){
            name_sender = Sender.Store.name;
            link_avatar = "";
            if(Sender.Store.logo){
                image=Sender.Store.logo;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = Feed.sender_type;
        }else{
            name_sender = "";
            link_avatar = "";
            image="images/icon/avatar.png";
            cat_sender = "";
        }

        if(Feed.object_type=="Book"){
            object_name = Object.Book.title;
            var list_author='';
            list_author +='<span class="black">by </span>';
            if(Object.Book.authors){
                object_det = 'by <span class="medium light-blue">'+Object.Book.authors+'</span>';
            }else{
               if(Object.Authors.length==0){
                  list_author+='<span class="medium"></span>';
                  object_det=list_author;
                }else{
                    $.each(Object.Authors,function(){
                        var id = this.id;
                        var name = this.name;
                        if(id){
                            list_author+='<span><a style="color:#62bdc3" href="#/main/moco/library/" onclick="authors_details('+id+')">'+name+' </a></span>';
                        }else{
                           list_author+='<span><a style="color:#62bdc3" onclick="">'+name+' </a></span>';
                        }
                    })  
                    object_det=list_author;
                }
            }
            //object_det = 'by '+'<span class="medium">'+Object.Book.authors+'</span>';
            //id,name,status,notif,d1,d2,d3,d4,d5,d6,d7,d8
            object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"',1,undefined,\'"+Object.Book.cover+"\')"
            //object_action = 'books('+Object.Book.id+')';
            //object_image = Object.Book.cover;
            object_image = '<img class="media-object" src="'+Object.Book.cover+'" style="width:65px;height:100px;position:absolute;right:0;">';
        }else if(Feed.object_type=="Library"){
            object_name = Object.Library.name;
            object_det = Object.Statistic.total_books+' Books';
            object_action = "n_pustaka("+Object.Library.id+",'"+Object.Library.name.replace(/ /g,'_')+"')";
            //object_action = 'pustaka('+Object.Library.id+')';
            //object_image = Object.Library.logo;
            object_image = '<img class="media-object" src="'+Object.Library.logo+'" style="width:65px;height:65px;position:absolute;right:0;">';
        }else if(Feed.object_type=="User"){
            object_name = Object.User.name;
            object_det = "";
            //object_action = "n_user("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"',1,undefined,'"+Sender.User.name.replace(/ /g,'_')+"','"+Sender.User.avatar+"')";
            object_action = "n_user("+Object.User.id+",'"+Object.User.name.replace(/ /g,'_')+"',1,undefined,'"+Object.User.name.replace(/ /g,'_')+"','"+Object.User.avatar+"')";
            //object_action = "n_user("+Object.User.id+",'"+Object.User.name.replace(/ /g,'_')+"',1)";
            //object_action = 'user_details('+Object.User.id+')';
            //object_image = Object.Library.logo;
            object_image = '<img class="media-object" src="'+Object.User.avatar+'" style="width:65px;height:65px;position:absolute;right:0;">';
        }else if(Feed.object_type=="Review"){
            object_name = '';
            object_det = '"'+limitCharacter(Object.Review.content,15)+'" <br><span onclick=notif_act_to("'+Object.Review.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:0px;cursor:pointer">Read More >> </span>';
            object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"',1,undefined,\'"+Object.Book.cover+"\')"
            //object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"',1)"
            //object_action = 'books('+Object.Book.id+')';
            object_image = '<img class="media-object" src="'+Object.Book.cover+'" style="width:65px;height:100px;position:absolute;right:0;">';
            action_next = "notif_act_to('"+Object.Review.id+"','"+Object.Book.id+"','books')";
        }else if(Feed.object_type=="Comment"){
            object_name = '';
            //console.log(Object.Book)
            if(Object.Book != undefined){
                object_det = '"'+limitCharacter(Object.Comment.comment,15)+'" <br><span onclick=notif_act_to("'+Object.Comment.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:0px;cursor:pointer">Read More >> </span>';
                object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"',1,undefined,\'"+Object.Book.cover+"\')"
                //object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"',1)"
                //object_action = 'books('+Object.Book.id+')';
                object_image = '<img class="media-object" src="'+Object.Book.cover+'" style="width:65px;height:100px;position:absolute;right:0;">';
                action_next = "notif_act_to('"+Object.Comment.id+"','"+Object.Book.id+"','books')";
            }else{
                object_det = "'"+limitCharacter(Object.Comment.comment,15)+"'";
                object_action = '';
                object_image = '';
                action_next = "";
            }
        }else if(Feed.object_type=="Badge"){
            object_name = Object.Badge.name;
            object_det = ".";
            object_action="";
            //object_image = Object.Badge.icon;
            object_image = '';
        }else{
            object_name = "";
            object_det = "";
            object_image="";
            //cat_sender = Notif.recipient_type;
        }

        feeds_text +='<div style="">\
        <div class="col-xs-1 col-md-1" style="padding:0px;padding-top:25px"><a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="'+image+'" style="width:44px;height:44px;"></a></div>\
        <div class="col-xs-11 col-md-11" style="padding-right:0px;padding-top:25px">\
        <div class="black" style="font-size:18px;cursor:pointer;" onclick="'+link_avatar+'">'+name_sender+'</div>\
        <div style="color:#888;font-size:14px;">'+cat_sender+'</div>\
        <div style="padding-top:10px;padding-bottom:10px;"><div class="divider" style="padding-top:0px;width:100%;"></div></div>\
        <div class="black" style="font-size:12px;">'+Feed.message+'</div>\
        <div class="col-xs-12 col-md-12" style="padding:0px;">\
        <div class="col-xs-10 col-md-10" style="padding:0px;">\
        <div class="black" style="font-size:20px;padding-top:12px;">'+object_name+'</div>\
        <div class="grey" style="font-size:14px;">'+object_det+'</div>\
        <div style="font-size:10px;color:#888;padding-top:30px;">'+Feed.elapsed_time+'</div>\
        </div>\
        <div class="col-xs-0 ol-md-0" style="padding:0;"><a href="#/main/moco/library/" onclick="'+object_action+'">'+object_image+'</a></div>\
        </div>\
        </div>\
        <div class="col-xs-12 col-md-12" style="padding:0px;padding-top:10px;padding-bottom:0px;"><div class="divider" style="padding-top:0px;"></div></div></div>';
        
    });
    $('#result_feeds').append(feeds_text);

}

function real_feeds(){
    user_id = window.localStorage.getItem('id');
    //alert listener
    //var es = new EventSource(realtime+':8080/subscribe?events=feed-'+user_id);
    var es = new EventSource('http://feed.moco.co.id:8080/?events=feed-'+user_id);
    es.addEventListener('message', function (e)
    {
        var feeds_text='';
        var event = JSON.parse(e.data);
        var data_feed = JSON.parse(event.message.default);
        //console.log(data_feed);

        var Feed = data_feed.Feed;
        var Sender = data_feed.Sender;
        var Object = data_feed.Object;
        //console.log(Feed)
        //if(Feed.action_type=="JOIN"){
        if(Feed.sender_type=="User"){
            name_sender = Sender.User.name;
            link_avatar = "user_details("+Sender.User.id+")";
            if(Sender.User.avatar){
                image=Sender.User.avatar;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = Sender.Badge.name;
        }else if(Feed.sender_type=="Author"){
            name_sender = Sender.Author.name;
            link_avatar = "authors_details("+Sender.Author.id+")";
            if(Sender.Author.avatar){
                image=Sender.Author.avatar;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = 'Author';
        }else if(Feed.sender_type=="Library"){
            name_sender = Sender.Library.name;
            link_avatar = "pustaka("+Sender.Library.id+")";
            if(Sender.Library.logo){
                image=Sender.Library.logo;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = "Library";
        }else if(Feed.sender_type=="Store"){
            name_sender = Sender.Store.name;
            link_avatar = "";
            if(Sender.Store.logo){
                image=Sender.Store.logo;
            }else{
                image="images/icon/avatar.png";
            }
            cat_sender = Feed.sender_type;
        }else{
            name_sender = "";
            link_avatar = "";
            image="images/icon/avatar.png";
            cat_sender = "";
        }

        if(Feed.object_type=="Book"){
            object_name = Object.Book.title;
            object_det = 'by '+'<span class="medium">'+Object.Book.authors+'</span>';
            object_action = 'books('+Object.Book.id+')';
            //object_image = Object.Book.cover;
            object_image = '<img class="media-object" src="'+Object.Book.cover+'" style="width:65px;height:100px;position:absolute;right:0;">';
        }else if(Feed.object_type=="Library"){
            object_name = Object.Library.name;
            object_det = Object.Library.address;
            object_action = 'pustaka('+Object.Library.id+')';
            //object_image = Object.Library.logo;
            object_image = '<img class="media-object" src="'+Object.Library.logo+'" style="width:65px;height:65px;position:absolute;right:0;">';
        }else if(Feed.object_type=="User"){
            object_name = Object.User.name;
            object_det = "";
            object_action = 'user_details('+Object.User.id+')';
            //object_image = Object.Library.logo;
            object_image = '<img class="media-object" src="'+Object.User.avatar+'" style="width:65px;height:65px;position:absolute;right:0;">';
        }else if(Feed.object_type=="Review"){
            object_name = '';
            object_det = '"'+limitCharacter(Object.Review.content,15)+'" <br><span onclick=notif_act_to("'+Notif.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:10px;cursor:pointer">Read More >> </span>';
            object_action = '';
            object_image = '';
            action_next = "notif_act_to('"+Notif.id+"','"+Object.Book.id+"','books')";
        }else if(Feed.object_type=="Comment"){
            object_name = '';
            //console.log(Object.Book)
            if(Object.Book != undefined){
                object_det = '"'+limitCharacter(Object.Comment.comment,15)+'" <br><span onclick=notif_act_to("'+Notif.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:10px;cursor:pointer">Read More >> </span>';
                object_action = '';
                object_image = '';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.Book.id+"','books')";
            }else{
                object_det = "'"+limitCharacter(Object.Comment.comment,15)+"'";
                object_action = '';
                object_image = '';
                action_next = "";
            }
        }else if(Feed.object_type=="Badge"){
            object_name = Object.Badge.name;
            object_det = ".";
            object_action="";
            //object_image = Object.Badge.icon;
            object_image = '';
        }else{
            object_name = "";
            object_det = "";
            object_image="";
            //cat_sender = Notif.recipient_type;
        }

        var feeds_text='';

        feeds_text +='<div style="">\
        <div class="col-xs-1 col-md-1" style="padding:0px;padding-top:25px"><a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="'+image+'" style="width:44px;height:44px;"></a></div>\
        <div class="col-xs-11 col-md-11" style="padding-right:0px;padding-top:25px">\
        <div class="black" style="font-size:18px;cursor:pointer;" onclick="'+link_avatar+'" >'+name_sender+'</div>\
        <div style="color:#888;font-size:14px;">'+cat_sender+'</div>\
        <div style="padding-top:10px;padding-bottom:10px;"><div class="divider" style="padding-top:0px;width:100%;"></div></div>\
        <div class="black" style="font-size:12px;">'+Feed.message+'</div>\
        <div class="col-xs-12 col-md-12" style="padding:0px;">\
        <div class="col-xs-10 col-md-10" style="padding:0px;">\
        <div class="black" style="font-size:20px;padding-top:12px;">'+object_name+'</div>\
        <div class="grey" style="font-size:14px;">'+object_det+'</div>\
        <div style="font-size:10px;color:#888;padding-top:30px;">'+Feed.elapsed_time+'</div>\
        </div>\
        <div class="col-xs-0 ol-md-0" style="padding:0;"><a href="#/main/moco/library/" onclick="'+object_action+'">'+object_image+'</a></div>\
        </div>\
        </div>\
        <div class="col-xs-12 col-md-12" style="padding:0px;padding-top:10px;padding-bottom:0px;"><div class="divider" style="padding-top:0px;"></div></div></div>';

         $('#result_feeds').prepend(feeds_text);
    });
    es.addEventListener('error', function (e)
    {
        //console.log(e);
      // var event = JSON.parse(e.data);
      // generate("bottomLeft",event.message.default);
    });
}