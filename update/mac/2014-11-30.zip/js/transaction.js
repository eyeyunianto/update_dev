var token = window.localStorage.getItem('token');
var keyhash,home;

function download_book(url,item_code,item_key,init,session,title,params,type){
  cover_book="";

  _ads_=0;
  if(ads_data.length>0){
    $('#_ads').click();//load ads
  }
  //$('#link_book_'+item_key).css('opacity','1');
  $('#book_cover_'+item_key).css('opacity','1');
  var html = '<div class="progress progress-striped active" style="position:relative;"> \
    <div id="progress-dw" class="progress-bar" aria-valuenow=""  role="progressbar" aria-valuemin="0" aria-valuemax="100"> \
      <span class="sr-only">% Complete</span> \
    </div> \
  </div>';
     
  //console.log(url,item_code,item_key,init,session,title,params);
  var filename ="";
  var home="";
  var status = window.localStorage.getItem('status');
  var file = url.split('/');
  filename = file[file.length - 1];

  //WIN
  //var keyhash = ign.hash(item_code);
  //home = ign.home_path();

  //MAC
  var keyhash = sys.hash(item_code,'sha512');
  home = fs.homePath();

  home += "/.ignsdk/"+filename;
    var b=fs.homePath()+'/.ignsdk/files/uploads/'+session+'/'+init+'_Book_'+item_key+'_/';
    act_book = 'read_this("'+b+'")';
    act_book2 = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+session+'/'+init+'_Book_'+item_key+'_.pdf"';
  //console.log(b);


  console.log(params)
  if(params==1){
    $('#book_cover_'+item_key).css('opacity','1');

    //WIN
    //console.log(sys.exec('unzip.exe -P '+keyhash+' '+'"'+home+'"'+' -d '+'"'+ign.home_path()+'/.ignsdk'+'"'));
    //console.log('unzip -P '+keyhash+' '+'"'+home.replace(/ /g,'%20')+'"'+' -d '+'"'+fs.homePath().replace(/ /g,'%20')+'/.ignsdk'+'"');
    
    //MAC
    console.log(sys.exec('unzip -P '+keyhash+' '+'"'+home.replace(/ /g,'%20')+'"'+' -d '+'"'+fs.homePath().replace(/ /g,'%20')+'/.ignsdk'+'"'));
    //console.log('unzip -P '+keyhash+' '+'"'+home+'"'+' -d '+'"'+fs.homePath()+'/.ignsdk'+'"');
    
    setTimeout(function(){
      console.log(type)
      if(fs.isExist(fs.homePath()+'/.ignsdk/files/uploads/'+session+'/'+init+'_Book_'+item_key+'_.zip')==true){
        console.log('true');
        var act_book = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+session+'/'+init+'_Book_'+item_key+'_.pdf"';
        //var opacity = 'opacity:1';
        $('#link_book_'+item_key).attr('onclick',act_book);

      }else{
        $('#link_book_'+item_key).attr('onclick','read_this("'+b+'")');
        $('#ads_act').removeAttr('disabled');
        $('#ads_act').attr('onclick','read_this("'+b+'")');
      }
      $('#book_cover_'+item_key).css('opacity',1);
      check_collection(item_key);
      setTimeout(function(){
        $('#book_cover_'+item_key).click();
        $('#link_book_'+item_key).click();
      },3000)
    },3000)
  }else{
    if (status=='false'|| status==""){
      $('#download_'+item_key).html(html);
      $('#download').html(html);
      window.localStorage.setItem('id_buku',item_key);
      ign.downloadProgress.connect(function(r,s){
        var persentation = (r/s)*100;
        $('#progress-dw').attr('aria-valuenow',persentation);
        $('#progress-dw').attr('style',"width:"+persentation+"%;");
        window.localStorage.removeItem('status');
        window.localStorage.setItem('status',true);
       if(persentation == 100){
          $('#download_'+item_key).empty();
          $('#download').empty();
           window.localStorage.removeItem('status');
           window.localStorage.setItem('status',false);
           window.localStorage.removeItem('id_buku');
          $('#load_image'+item_key).html('<center style="position:absolute;left:0;right:0;top:50px;bottom:0;margin:auto;"><img src="css/plugin/images/bx_loader2.gif"></center>')
          setTimeout(function(){
          var home_p= fs.homePath()+'/.ignsdk';
          console.log(home);
          console.log(keyhash);
          console.log(home_p);
            fs.unzip(home,keyhash,home_p);
            console.log('fs.unzip('+home+','+keyhash+','+home_p+')')
            //console.log(home,keyhash,home_p);
            //console.log(act_book);

            $('#ads_act').removeAttr('disabled');   
            //console.log(type)         
            if(type=="pdf"){
              console.log('pdf')
              //console.log(act_book2)
              //var opacity = 'opacity:1';
              $('#link_book_'+item_key).attr('onclick',act_book2);
              $("#book_cover_"+item_key).attr('onclick',act_book2);
              $('#btn-getbooks').attr('onclick',act_book2);
              $('#ads_act').attr('onclick',act_book2);
            }else{
              console.log('epub')
              $("#link_book_"+item_key).attr('onclick',act_book);
              $("#book_cover_"+item_key).attr('onclick',act_book);
              $('#btn-getbooks').attr('onclick',act_book);
              $('#ads_act').attr('onclick',act_book);
            }
            
            
            
            check_collection(item_key,undefined,'extract');
            setTimeout(function(){
              $('#load_image'+item_key).html("");
              $('#book_cover_'+item_key).click();
              $('#link_book_'+item_key).click();

              //$('#btn-getbooks').click();
              // 
            },3000)
          },3000) 
      }
        });

        console.log(url);
		    var home_p= fs.homePath()+"/.ignsdk";
        console.log(ign.download(url,home_p));
    }
  }
}

function set_pass(){
    setTimeout(function(){
        $('.modalDialog').css('width','290px').css('height','180px').css('border-radius','6px').css('margin','15% auto');
        $('#main_layout').addClass('css3-gaussian-blur');
        var html='<center>\
          <p id="pass_title" class="grey" style="padding-top:10px;">Enter Your Password</p>\
          <p><input id="password_trx" type="password" class="form-control input-group-sm" placeholder="Your Password" style="height:40px;padding-top:10px;"></p>\
          <button class="btn btn-default" style="background-color: #1ebe8e;color:#fff;padding:5px 40px;border-radius: 21px;" id="btn-final-trx">OK</button>\
          </center>';
        $('#transaction_confirm').html(html);
    },500);
}

var confirm_password;

function check_password(){
  $(window).keyup(function(){
    confirm_password = $('#password_trx').val();
  });
}

function trx(){
  setTimeout(function(){
      $('.modalDialog').css('width','300px').css('height','450px').css('border-radius','6px').css('margin','12% auto');
      $('#main_layout').addClass('css3-gaussian-blur');
      $('#day_borrow').html(books_day);
      $('#points_buy').html('<b>'+books_buy+'</b> Points');
      $('#points_borrow').html('<b>'+books_borrow+'</b> Points');
  },500);
}

function buy(){
  setTimeout(function(){
    if(books_buy==undefined){
      nomine="0";
    }else{
      nomine=books_buy;
    }
    $('.modalDialog').css('width','300px').css('height','300px').css('border-radius','6px').css('margin','15% auto');
    $('#main_layout').addClass('css3-gaussian-blur');
    var html='<center>\
      <p class="grey" style="font-size:18px">You`re going to spend :</p>\
      <p style="font-size:60px;position:absolute;left:0;right:0;top:70px;" id="points_cost">'+nomine+'</p>\
      <p class="grey" style="font-size:30px;padding-top:100px;padding-bottom:15px;">points</p>\
      <button class="btn btn-default" style="background-color: #1ebe8e;color:#fff;padding:10px 40px;border-radius: 21px;" onclick="_buy()">CONFIRM</button>\
      </center>';
    $('#cost_spend').html(html);
    check_password();
  },500);
}

function _buy(){
  $('#pass_trans').click();
  ga_action('Book','Confirm',books_title,nomine);
  setTimeout(function(){
    //check_password();
    $('#btn-final-trx').attr('onclick','buy_books()');
  },500)
}

function _rent(){
  ga_action('Book','Confirm',books_title,nomine);
  $('#pass_trans').click();
  setTimeout(function(){
    //check_password();
    $('#btn-final-trx').attr('onclick','rent_books()');
  },500)
}

function books_rent(){
  setTimeout(function(){
    if(books_borrow==undefined){
      nomine="0";
    }else{
      nomine=books_borrow;
    }
    $('.modalDialog').css('width','300px').css('height','300px').css('border-radius','6px').css('margin','15% auto');
    $('#main_layout').addClass('css3-gaussian-blur');
    var html='<center>\
      <p class="grey" style="font-size:18px">You`re going to spend :</p>\
      <p style="font-size:60px;position:absolute;left:0;right:0;top:70px;" id="points_cost">'+nomine+'</p>\
      <p class="grey" style="font-size:30px;padding-top:100px;padding-bottom:15px;">points</p>\
      <button class="btn btn-default" style="background-color: #1ebe8e;color:#fff;padding:10px 40px;border-radius: 21px;" onclick="_rent()">CONFIRM</button>\
      </center>';
    $('#cost_spend').html(html);
    check_password();
  },500);
}

/*
function borrow_books(id,key){
  var req_data = {'access_token':token,'book_id':books_id,'library_id':library_id};
    $.ajax({
      type: 'POST',
      url: url+'books/borrow_book',
      data: req_data,
      dataType:"json",
      beforeSend:function(result){
      },
      success: function(result){
        if(result.meta.code == 200){
            //alert("sukses");
        $("#moco-add-collection").attr("class","fa fa-check-circle");
        check_collection(id);
        setTimeout(function(){
        $('#Koleksi').click();
        },5000);
            }else{
        alert('"'+result.meta.error_message+'"');
      }
    }
  });
}
*/

function rent_books(){
  var token= window.localStorage.getItem('token');
  var data ={'access_token':token,'password':confirm_password,'book_id':books_id,'price_id':price_id};
  //add reload
  var before=$('#transaction_confirm').html('<center style="padding-top:20px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  var post = majax_post('books/rent',data,before);
  post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
        Moco.content = "";
        console.log(data);
          Moco.content="Your book has been added to collection";
          $('#confirm_trans_success').click();
          check_collection(books_id);
          /*
          setTimeout(function(){
          $('#Koleksi').click();
          },5000); */ 
      }
      else{
        //$('#confirm_trans_failed').click();
          var msg = "";
          // $.each(data.meta.error_message,function(i,j){
          //     if(i == 0){
          //         msg += j;   
          //     }
          //     else{
          //         msg += ","+j; 
          //     }
          // });
          //alert(msg);
          Moco.content=data.meta.error_message;
          $('#confirm_trans_failed').click();

          //$('#btn_trans').removeAttr('data-ember-action');
          //$('#btn_trans').attr('onclick','javascript:$("#btn-forgot").click()');
      }
  });
}

function buy_books(){
  var token= window.localStorage.getItem('token');
  var data ={'access_token':token,'password':confirm_password,'book_id':books_id};
  //add reload
  var before=$('#transaction_confirm').html('<center style="padding-top:20px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  var post = majax_post('books/buy',data,before);
  post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
          //alert("Pembelian Buku Sukses");
          //window.location.href='#close';
          //console.log(data);
          Moco.content="Your book has been added to collection";
          $('#confirm_trans_success').click();
          check_collection(books_id);
          /*
          setTimeout(function(){
            $('#Koleksi').click();
          },5000);  */
      }
      else{
        //$('#confirm_trans_failed').click();
        //$('#message warning').html(data.meta.error_message);
          // var msg = "";
          // $.each(data.meta.error_message,function(i,j){
          //     if(i == 0){
          //         msg += j;   
          //     }
          //     else{
          //         msg += ","+j; 
          //     }
          // });
          //alert(msg);
          //$('#message_warning').html(msg);
          Moco.content=data.meta.error_message;
          $('#confirm_trans_failed').click();
      }
  });
}

function check_collection(id,action_,extract){
  _ads_=0;
  var token= window.localStorage.getItem('token');
  var req_data = {'access_token':token,'client_id':client_id};
  var action = new majax('books/has_book',{'access_token':token,'book_id':id});
  // var action = new majax_fast('books/has_book',{'access_token':token,'book_id':id,'client_id':client_id});
  action.success(function(data){
    var status=data.data.has_book;
    var item = data.data.Item;
    var Book = data.data.Book;
    //console.log(Book)
    //console.log(data);
    if (status=='true'){
      $("#btn-getbooks").text("Download");
      $('#btn-getbooks').removeAttr('data-ember-action');
      $('#btn-want').css('color','#888888');
      $('#btn-history').css('color','#888888');
      $('#icn-want').css('color','#888888');
      $('#icn-history').css('color','#888888');
      $('#btn-want').attr('onclick','');
      $('#btn-history').attr('onclick','');
      //overview(id);
      $('#epustaka').css('visibility','hidden');

      //windows
      //var root = ign.home_path()+"/.ignsdk/";

      //MAC
      if (navigator.appVersion.indexOf("Win")!=-1){
        var root = fs.homePath()+"/.ignsdk/";
      }else{
        var root = fs.homePath()+"/.ignsdk/";
      }

      var a=item.out.split('/');
      // console.log(a)
      if(a[a.length-1]==undefined){
        console.log('link_corrupt')
        var path_file_name = 0;
        var filename = 0;
        var key = 0;
        update_file('Book',item.id);
      }else{
        var path_file_name = root+a[a.length-1];
        var file_name = a[a.length-1];
        //var path_file_name = item.out.replace(link+'files/uploads/',root);
        //var file_name = item.out.replace(link+'files/uploads/',"");
        //var key = file_name.replace("_"+item.type+"_"+item.key+"__out.zip","");
        var key2 = file_name.split('_');
        var key = key2[0];
        // console.log(path_file_name);
        // console.log(file_name);
        // console.log(key);

      //windows
      //if(ign.checkbook(path_file_name)){
	
	//console.log(path_file_name)
      //MAC
      if(fs.isExist(path_file_name)){
        console.log('file exist')
        //var reader = 'location.href="reader.html#'+book.title+'#'+item.session+'/'+key+'_Book_'+item.key+'_"';
        var reader='Comming soon';
        var opacity = 'opacity:1';
        //$("#btn-getbooks").attr("onclick",reader;
        //$("#btn-getbooks").html("Read");
        if($('#expires_books').html()!=""){
          $('.expires').show();
        }
        //$("#btn-getbooks").css("background-color","#1ebe8e");
        if (navigator.appVersion.indexOf("Win")!=-1){
            b=item.session+'/'+key+'_Book_'+item.key+'_';
        }else{
            b=item.session+'/'+key+'_Book_'+item.key+'_';
        }
          

          //WIN
          //var home = ign.home_path().replace(/ /g,'%20');
          //var located = ign.home_path()+'/.ignsdk/files/uploads/'+b+'/';
          
          //MAC
          var home = fs.homePath();
          //var located = fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
          if (navigator.appVersion.indexOf("Win")!=-1){
            var located=home+'/.ignsdk/files/uploads/'+b+'/';
            located=located
          }else{
            var located=fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
          }
          //console.log(located)
          var buku_judul =1;

          //WIN
          //if(ign.checkbook(located+"/OEBPS/toc.ncx")==false){

          //MAC
          console.log(located);
          if(fs.isDirectory(located)==false){
            console.log('directory not found')
            var ax = item.out.split('/');
            console.log(ax)
            if(ax[ax.length-1]==undefined){

              var act_book="update_file('Book',"+item.id+")";
            }else{
              var act_book = 'download_book(\''+item.out+'\',\''+item.pass+'\',\''+item.key+'\',\''+key+'\',\''+item.session+'\',\''+buku_judul+'\',undefined,\''+Book.extension+'\')';
            }
          }else{
			      console.log('dir exist')
            //WIN
            //var act_book = 'read_this("'+ign.home_path()+"/.ignsdk/files/uploads/"+b+'")';

            //MAC
            if (navigator.appVersion.indexOf("Win")!=-1){
		          console.log('win read')
              var b=home.replace(/ /g,'^^^')+'/.ignsdk/files/uploads/'+b+'/';
              var act_book = 'read_this("'+b+'")';
            }else{
              var b=fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
              var act_book = 'read_this("'+b+'","","","'+Book.cover+'")';
            }
            //var act_book = 'read_this("'+fs.homePath()+"/.ignsdk/files/uploads/"+b+'/")';
            $('#btn-getbooks').html('Read');
            $('#btn-getbooks').css("background-color",'#1ebe8e');
          }
          if(Book.extension=="pdf"){
            console.log('pdf')
            // console.log(fs.isExist(fs.homePath()+'/.ignsdk/files/uploads/'+item.session+'/'+key+'_Book_'+item.key+'_.pdf'))
            // console.log(fs.homePath()+'/.ignsdk/files/uploads/'+item.session+'/'+key+'_Book_'+item.key+'_.pdf')
            console.log(fs.homePath()+'/.ignsdk/files/uploads/'+item.session+'/'+key+'_Book_'+item.key+'_.pdf');
            if(fs.isExist(fs.homePath()+'/.ignsdk/files/uploads/'+item.session+'/'+key+'_Book_'+item.key+'_.pdf')==true){
              console.log('true');
              var act_book = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+item.session+'/'+key+'_Book_'+item.key+'_.pdf&cov='+Book.cover+'"';
              //var opacity = 'opacity:1';
              $('#btn-getbooks').html('Read');
              $('#btn-getbooks').css("background-color",'#1ebe8e');
            }else{
              if(extract=="extract"){
                console.log('update file corrupt')
                // console.log(Book.id)
                // update_file('Book',Book.id,'reload');
              }
            }
          }
          $("#btn-getbooks").attr("onclick",act_book);
          $('#ads_act').html('Read');
          $('#ads_act').removeAttr('disabled');
          $('#ads_act').attr('onclick',act_book);
          //console.log('satu');
        }else{
            var buku_judul =1; 
            var download = 'download_book(\''+item.out+'\',\''+item.pass+'\',\''+item.key+'\',\''+key+'\',\''+item.session+'\',\''+buku_judul+'\')';
            //console.log('else')
            var opacity = 'opacity:.4';
            // $("#btn-getbooks").html("Read");
            $('#btn-getbooks').css("background-color",'#c92036');
            $("#btn-getbooks").html("Download");
            $("#btn-getbooks").attr("onclick",download);
            setTimeout(function(){
              if(status_pustaka==1){
                // $('#btn-getbooks').click();
                // status_pustaka=0;
              }
              if(download_bebas==1){
                //$('#btn-getbooks').click();
                download_bebas=0;
              }
              if(action_==1){
                $('#btn-getbooks').click();
              }
            },500);
        }
      }
    }else{
      has_history(id);
      has_want(id);
        //alert("salah brow");
    }
  });
}

var download_bebas=0;

function download_free(id,data){
  // if(data){
  //   $('#_ads').click();//load ads
  // }
  var token= window.localStorage.getItem('token');
  var req_data = {'access_token':token,'book_id':id};
  $.ajax({
    type: 'POST',
    url: url+'books/download_free',
    data: req_data,
    dataType:"json",
    beforeSend:function(result){
      $("#moco-load").addClass('fa-spinner fa-spin')
    },
    success: function(result){
      $("#moco-load").removeClass('fa-spinner fa-spin')
        if(result.meta.code == 200){
          //overview(id);
          check_collection(id,1);
          download_bebas=1;
            //alert("sukses");
            }else{
        //alert('"'+result.meta.error_message+'"');
        //overview(id);
        Moco.content=data.meta.error_message;
        $('#confirm_trans_failed').click();
        download_bebas=0;
      }
    },
    error:function(result){
      $("#moco-load").removeClass('fa-spinner fa-spin')
    }
  });
}

function overview(id){
  var token= window.localStorage.getItem('token');
  var req_data = {'access_token':token,'client_id':client_id,'per_page':1010};
  Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
      if (obj.hasOwnProperty(key)) size++;
    }
    return size;
  };
    $.ajax({
    type: 'GET',
    url: url+'items',
    data: req_data,
    dataType:"json",
    beforeSend:function(result){
    },
    success: function(result){
      if(result.meta.code == 200){
        var cnt= Object.size(result.data.data);
        for(i=0;i<cnt;i++) {
          //console.log(result.data.data);
          var book = result.data.data[i].Book;
          var item = result.data.data[i].Item;
        if (item.key==id){
          //windows
          //var root = ign.home_path()+"/.ignsdk/";
          //MAC      
          }
        }
      }
    }
  });   
}

function from_libraries(){
    var book='';
    //var token =window.localStorage.getItem('token');
    var check = new majax('books/detail',{'client_id':client_id,'book_id':books_id},'');
    book +='<div class="media col-md-12" style="margin-top:20px;padding-left:10px;background-color:#ddd;">\
            <div class="col-md-12" style="margin-top:10px;padding-left:0px;">\
              <p class="black">Borrow this book from : </p>\
            </div>\
            </div>';
    $('.modalDialog').css('padding','5px 0px 13px 0px');
    $('#main_layout').addClass('css3-gaussian-blur');
    check.success(function(data){
      if(data.meta.code==200){
        var lib = data.data.Libraries;
        //console.log(lib);
        $.each(data.data.Libraries,function(){
          var Library = this.Library;
          var Statistic = this.Statistic;
          book+='<div class="media col-md-12" style="padding-left:10px;">\
            <div class="col-md-1" style="margin-top:10px;padding-left:0px;">\
              <img class="media-object" src="'+Library.logo+'" style="width:50px;height:50px;">\
            </div>\
            <div class="media-body col-md-9" style="margin-left:30px">\
              <div class="black">'+Library.name+'</div>\
              <div class="grey">'+Statistic.total_books+' Books</div>\
            </div>\
            <div class="col-md-1"style="top:20px"><a href="index.html#/main/details/pustaka/'+Library.id+'" onclick="goto_pustaka('+Library.id+')"><span class="fa fa-chevron-right grey"><span></a></div>\
            <div class="divider"></div>\
            </div>';});
        //console.log(book);
        $('#follow_content').html(book);
      }else{
        //$('#follow').html("Followers");
        $('#follow_content').html("Book can't be found on all library");
        //$('#follow_content').html(data.meta.error_message);
      }
    });
}

function get_list_pustaka(){
  $('.modalDialog').css('padding','5px 0px 13px 0px');
  $('#main_layout').addClass('css3-gaussian-blur');
  $('#follow_content').css('margin-top','10px');
  $('#follow_content').html(borrow_pustaka);
  $('#close_pass').removeAttr('data-ember-action');
  $('#close_pass').attr('onclick','javascript:$("#_get_books").click();');
}

function goto_pustaka(id){
  $('.x').click();
  setTimeout(function(){
    window.location.href="index.html#/main/details/pustaka/"+id+"/";
    setTimeout(function(){
      pustaka_cov(id);
    },500);
  },500);
}

function f_get_books(){
  setTimeout(function(){
    if(status_pustaka==1){
      $('.modalDialog').css('width','240px').css('height','260px').css('border-radius','6px').css('margin','15% auto').css('padding','0');
      // $('._get_borrow').css('display','block');
      $('#main_layout').addClass('css3-gaussian-blur');
      $('#action_borrow').removeAttr('disabled');
      if(books_day!=undefined){
        $('#day_borrow').html(' ('+books_day+' Days)');
        $('#points_buy').html('<b>'+books_buy+'</b> Points');
        $('#points_rent').html('<b>'+books_rent_nom+'</b> Points');
        if(books_buy==0){
          $('#points_buy').attr('disabled','disabled')
          $('#points_buy').html('Not Available')
        }
        if(books_rent_nom==undefined){
          $('#points_rent').attr('disabled','disabled')
          $('#points_rent').html('Not Available')
        }
      }
    }else{
      $('.modalDialog').css('width','240px').css('height','250px').css('border-radius','6px').css('margin','15% auto').css('padding-left','42px');
      $('#action_borrow').html('Not Available');
      if(books_day!=undefined){
        $('#day_borrow').html(' ('+books_day+' Days)');
        $('#points_buy').html('<b>'+books_buy+'</b> Points');
        $('#points_rent').html('<b>'+books_rent_nom+'</b> Points');
        if(books_buy==0){
          $('#points_buy').attr('disabled','disabled')
          $('#points_buy').html('Not Available')
        }
        if(books_rent_nom==undefined){
          $('#points_rent').attr('disabled','disabled')
          $('#points_rent').html('Not Available')
        }
      }
    }
    
  },200);
}

function f_conf_join(){
  setTimeout(function(){
    $('.modalDialog').css('width','290px').css('height','320px').css('border-radius','6px').css('margin','15% auto');
    $('#main_layout').addClass('css3-gaussian-blur');
  },100);
}

function update_file(jenis,id,act){
  var token = window.localStorage.getItem('token');
  var check = new majax_post('items/update_file',{'access_token':token,'type':jenis,'key':id},'');
  check.success(function(data){
    if(data.meta.code==200){
      console.log(data.meta.confirm);
      //overview(id);
      if(act=="reload"){
        books_cov(id);
        books_current();
      }else{
        check_collection(id);
      }
      // Moco.content=data.data; 
      // $('#confirm_trans_success').click();
      // $('#link_book_'+id).css('display','none')
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
}

//apis/orders/mandiri_matm (POST : access_token,product_type,product_key,phone)

function mandiri_matm(){
  var token= window.localStorage.getItem('token');
  var data = {'access_token':token,'product_type':'Voucher','product_key':voucher_id,'phone':confirm_password};
  //var data ={'access_token':token,'password':confirm_password,'book_id':books_id,'price_id':price_id};
  var post = majax_post('orders/mandiri_matm',data,'');
  post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
        //Moco.content = "";
        //console.log(data);
        Moco.content=data.meta.confirm;
        $('#confirm_trans_success').click();
          // check_collection(books_id);
          /*
          setTimeout(function(){
          $('#Koleksi').click();
          },5000); */ 
      }
      else{
        //$('#confirm_trans_failed').click();
          var msg = "";
          $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }
              else{
                  msg += ","+j; 
              }
          });
          //alert(msg);
          Moco.content=msg;
          $('#confirm_trans_failed').click();
      }
  });
}

function set_phone(){
    setTimeout(function(){
      check_password();
        $('.modalDialog').css('width','290px').css('height','180px').css('border-radius','6px').css('margin','15% auto');
        $('#main_layout').addClass('css3-gaussian-blur');
        $('#close_pass').attr('onclick',"$('#bank_choice').click()")
        var html='<center>\
          <p id="pass_title" class="grey" style="padding-top:10px;font-size:15px;">Enter Your Phone Number</p>\
          <p><input id="password_trx" type="text" placeholder="+62" class="form-control input-group-sm" placeholder="Your Phone Number" style="height:40px;padding-top:10px;"></p>\
          <button class="btn btn-default" onclick="mandiri_matm()" style="background-color: #1ebe8e;color:#fff;padding:5px 40px;border-radius: 21px;" id="btn-mandiri-trx">OK</button>\
          </center>';
        $('#transaction_confirm').html(html);
    },100);
}

function mandiri_topup(){
    if(voucher_id==null || voucher_id==undefined || voucher_id==""){
        alert("You Must Select Voucher First");
    }else{
      $('#phone').click();
      set_phone();
    }
}
function bca_topup(){
    if(voucher_id==null || voucher_id==undefined || voucher_id==""){
        alert("You Must Select Voucher First");
    }else{
         topup_vouchers();
    }
}
function trans_topup(){
  // alert("Will be available soon");
  $('#transfer').click();
}

function pay_method(data){
  $('#topup_close').click();
  if(data==1){
    trans_topup();
  }else if (data==2){
    topup_vouchers();
  }else if(data==3){
    $('#phone').click();
    setTimeout(function(){
      set_phone();
    },100)
  }else if (data==4){
    alert('Will Be available Soon')
  }else if (data==5){
    alert('Will Be available Soon')
  }else{

  }
}

function topup_kode(){
  var token= window.localStorage.getItem('token');
  var data = {'access_token':token,'product_type':'Voucher','product_key':voucher_id};
  //var data ={'access_token':token,'password':confirm_password,'book_id':books_id,'price_id':price_id};
  var post = majax_post('orders/transfer_payment',data,'');
  post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
        Moco.content = "";
        console.log(data);
          // Moco.content="Your book has been added to collection";
          // $('#confirm_trans_success').click();
          // check_collection(books_id);
          /*
          setTimeout(function(){
          $('#Koleksi').click();
          },5000); */ 
      }
      else{
        //$('#confirm_trans_failed').click();
          var msg = "";
          $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }
              else{
                  msg += ","+j; 
              }
          });
          //alert(msg);
          // Moco.content=msg;
          // $('#confirm_trans_failed').click();
      }
  });
}

function topup_token(){
  var token= window.localStorage.getItem('token');
  var data = {'access_token':token,'code':$('#token_input').val()};
  //var data ={'access_token':token,'password':confirm_password,'book_id':books_id,'price_id':price_id};
  var post = majax_post('vouchers/topup_by_code',data,'');
  post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
        Moco.content = data.data;
        //console.log(data);
          // Moco.content="Your book has been added to collection";
        $('#confirm_trans_success').click();
        profile();
          // check_collection(books_id);
          /*
          setTimeout(function(){
          $('#Koleksi').click();
          },5000); */ 
      }
      else{
        //$('#confirm_trans_failed').click();
          var msg = "";
          if($.isArray(data.meta.error_message)){
            $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }
              else{
                  msg += ","+j; 
              }
            });
          }else{
            msg = data.meta.error_message;
          }
          
          //alert(msg);
          Moco.content=msg;
          $('#confirm_trans_failed').click();
          setTimeout(function(){
            $('#btn_trans').attr('onclick',"$('#top_token_').click()").css('bottom','15px');
          },100)
      }
  });
}

function point_gift(){
  var html ="";
  html+='<div>\
    <div class="voucher" id="voucher_10000" onclick="set_gift_point(10000)" style="cursor:pointer;float:left">\
      <center>\
      <div style="visibility:hidden">10</div>\
      <div class="medium" style="font-size:50px;line-height:1;padding-top:15px;">10</div>\
      <div style="font-size:18px"><span>Points</span></div>\
      </center>\
    </div>\
    <div class="voucher" id="voucher_20000" onclick="set_gift_point(20000)" style="cursor:pointer;float:right">\
      <center>\
      <div style="visibility:hidden">20</div>\
      <div class="medium" style="font-size:50px;line-height:1;padding-top:15px;">20</div>\
      <div style="font-size:18px"><span>Points</span></div>\
      </center>\
    </div>\
    </div>'
  html+='<div>\
    <div class="voucher" id="voucher_50000" onclick="set_gift_point(50000)" style="cursor:pointer;float:left;margin-top:15px;">\
      <center>\
      <div style="visibility:hidden">50</div>\
      <div class="medium" style="font-size:50px;line-height:1;padding-top:15px;">50</div>\
      <div style="font-size:18px"><span>Points</span></div>\
      </center>\
    </div>\
    <div class="voucher" id="voucher_100000" onclick="set_gift_point(100000)" style="cursor:pointer;float:right;margin-top:15px;">\
      <center>\
      <div style="visibility:hidden">100</div>\
      <div class="medium" style="font-size:50px;line-height:1;padding-top:15px;">100</div>\
      <div style="font-size:18px"><span>Points</span></div>\
      </center>\
    </div>\
    </div>'
  setTimeout(function(){
    //$('#follow_content').html(html);
    $('#list_voucher').html(html)
  },500)
}

function set_gift_point(point){
  $('#right_header').attr('onclick','send_gift_poin('+point+')');
  $('.voucher').css('background-color','#1ebe8e')
  $('#voucher_'+point).css('background-color','#ffcd44')
}

function send_gift_poin(point){
  var a = point.toString();
  var poin = a.slice(0, -3);
  console.log(poin)
  $('#gift_success').click();
  setTimeout(function(){
    $('#desc').html(rec_user[1]);
    $('#conf_gift').attr('onclick','send_gift('+rec_user[0]+','+point+')')
    $('#point_spent').html(poin);
  },100)
}

function send_gift(id,point){
  var token= window.localStorage.getItem('token');
  var data = {'access_token':token,'client_secret':client_secret,'client_id':client_id,'balance':point,'user_id':id};
  var before = $('#conf_gift').html('').attr('disabled','disabled').addClass('fa fa-spinner fa-large')
  var post = majax_secure('gift',data,'');
  post.success(function(data){
      if(data.meta.code == 200){
        console.log(data);
        Moco.content=data.meta.confirm;
        $('#confirm_trans_success').click();
        profile();
      }
      else{
        //$('#confirm_trans_failed').click();
        console.log(data)
        var msg = data.meta.error_message;
        //alert(msg);
        Moco.content=msg;
        $('#confirm_trans_failed').click();
      }
  });
}


