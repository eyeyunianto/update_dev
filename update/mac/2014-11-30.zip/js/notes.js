(function($) {
    $.fn.extend( {
        limiter: function(limit, elem) {
            $(this).on("keyup focus", function() {
                setCount(this, elem);
            });
            function setCount(src, elem) {
                var chars = src.value.length;
                if (chars > limit) {
                    src.value = src.value.substr(0, limit);
                    chars = limit;
                }
                elem.html( limit - chars );
            }
            setCount($(this)[0], elem);
        }
    });
})(jQuery);

var note_id;
var page_note,count_note;
function get_notes(status){
    $('#load_more').css('visibility','hidden');
    $('#notes_action_more').attr('onclick','more_get_notes('+status+')');
    page_note =0;
    count_note =2;
    var local = ReadData('_notes');
    if(local!=null){
      //console.log(local);
      $('#notes_index').html('');
      parse_notes(local);
    }else{
        var before =$('#notes_index').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    }
    var token = window.localStorage.getItem('token');
    var notes = new majax('notes/index',{'access_token':token,'per_page':10},'');
    note_text ='';
    notes.success(function(data){
        if(data.meta.code==200){
            count = data.data.total_result;
            page_note = data.data.num_pages;
            if(page_note>1){
                $('#load_more').css('visibility','visible');
              }else{
                $('#load_more').css('visibility','hidden');
              }

            WriteData('_notes', data)
            if(local==null){
                  //console.log(local);
                $('#notes_index').html('');
                parse_notes(data);
            }else{
                $('#notes_index').html('');
                parse_notes(data);
            }

            setTimeout(function(){ThisAnim('#notes_index','fadeInRight')},200);
            if(status=="true"){
                $('.btn-del').css('display','block');
                $('#btn-edit').css('color','#c92036');
            }
            jQuery(document).ready(function() {
                jQuery("abb.timeago3").timeago();
            });
            var elem = $("#chars");

            //$("#message").limiter(100, elem);
            $("#note_title").limiter(100, elem);
            edit_notes();
        }else{
            $('#notes_index').html('');
            $('#load_more').css('visibility','hidden');
        }
        
    });
    notes.error(function(data){
        //alert('Network Error');
        // Moco.content="No Internet Connection";
        // $('#confirm_trans_failed').click();
        $('#load_more').css('visibility','hidden');
        //goto_current();
    });
}

function more_get_notes(status){
    if(count_note<=page_note){
        var token = window.localStorage.getItem('token');
        var notes = new majax('notes/index',{'access_token':token,'per_page':10,'page':count_note},'');
        note_text ='';
        notes.success(function(data){
            if(data.meta.code==200){
                count_note ++;
                //$('#load_more').attr('onclick','more_get_notes('+status+','+count_note+')');
                count = data.data.total_result;
                
                parse_notes(data);
                
                //setTimeout(function(){ThisAnim('#notes_index','fadeInRight')},200);
                if(status=="true"){
                    $('.btn-del').css('display','block');
                    $('#btn-edit').css('color','#c92036');
                }
                jQuery(document).ready(function() {
                    jQuery("abb.timeago3").timeago();
                });
                var elem = $("#chars");

                //$("#message").limiter(100, elem);
                $("#note_title").limiter(100, elem);
                edit_notes();
            }else{
                $('#notes_index').append('');
            }
            
            });
        notes.error(function(data){
            // alert('Network Error');
            // Moco.content="No Internet Connection";
            // $('#confirm_trans_failed').click();
        });
    }else{
        $('#load_more').css('visibility','hidden');
    }
}

function parse_notes(data){
    var note_text="";
    $.each(data.data.data,function(){
        var note = this.Note;
        var child = this.children;
        var created_time=change_time(note.modified);
        note_text += '<div style="">\
                        <div style="padding-bottom:0px;cursor:pointer;" onclick="details_notes('+note.id+')">\
                            <div class="col-xs-1 col-md-2 btn-del" style="padding:0;padding-top:25px;margin-left:30px;display:none;z-index:100;margin-right:5px;text-align:center"><i href="#/main/notes" onclick="del_notes('+note.id+')" class="fa fa-minus-circle" style="color:#b31635;font-size:20px;"></i>\
                            </div>\
                            <div class="list_notes" id="index_'+note.id+'" style="padding-top:12px;width:100%;padding-right:0px;z-index:100;">\
                                <div class="_title" id="_title'+note.id+'" style="padding-left:30px;">'+limitCharacter(note.title,25)+'</div>\
                                <div style="padding-bottom:8px;padding-left:30px;"><abb class="timeago3 grey _time" id="_time'+note.id+'" title="'+created_time+'" style="font-size:10px;"></abb></div>\
                            </div>\
                            <div class="col-md-12 col-xs-12" style="padding-top:0px;padding-left:30px;">\
                                <div class="divider" style="padding-top:0px;"></div>\
                            </div>\
                        </div>\
                    </div>';
        //console.log(jQuery.isEmptyObject(child));

        // if(jQuery.isEmptyObject(child)==true){
        //     console.log('empty');
        // }else{
        //     console.log(child)
        //     $.each(child,function(){
        //         var note = this.Note;
        //         console.log(note)
        //         var created_time=change_time(note.modified);
        //         note_text += '<div style="height:70px;padding-left:20px;" class="list_notes" id="index_'+note.id+'">\
        //         <div style="height:70px;padding-bottom:0px;cursor:pointer;padding-left:25px;" onclick="details_notes('+note.id+')">\
        //         <div class="col-xs-1 col-md-1 btn-del" style="padding-top:25px;display:none;"><i href="#/main/notes" onclick="del_notes('+note.id+')" class="fa fa-minus-circle" style="color:#b31635;font-size:20px;"></i></div>\
        //         <div class="col-xs-10 col-md-11" style="padding-top:12px;"><div class="_title" id="_title'+note.id+'">'+note.title+'</div>\
        //         <div><abb class="timeago3 grey _time" id="_time'+note.id+'" title="'+created_time+'" style="font-size:10px;"></abb></div></div>\
        //         </div></div>\
        //         <div style="padding-left:25px;"><div class="divider" style="padding-top:0px;"></div></div>';
        //     });
        // }
    }); 
    $('#notes_index').append(note_text);
}

function del_notes(id){
    var token =window.localStorage.getItem('token');
    var data ={'access_token':token,'note_id':id};
    var post = majax_post('notes/delete',data,'');
    post.success(function(data){
        //console.log(data);
        if(data.meta.code == 200){
            Moco.content=data.data;
            $('#confirm_trans_success').click();
            //alert("Berhasil menghapus Notes");
            get_notes("true");
        }
        else{
            var msg = "";
            $.each(data.meta.error_message,function(i,j){
                if(i == 0){
                    msg += j;   
                }
                else{
                    msg += ","+j; 
                }
            });
            alert(msg);
        }
    });
}

function add_notes(){
    ga_action('Notes','Add');
    var token =window.localStorage.getItem('token');
    var title_note = $('#note_title').val();
    var data_note = $('#message').val();
    var data={'access_token':token,'title':title_note,'note':data_note};
        var post = majax_post('notes/add',data,'');
        post.success(function(data){
        //console.log(data);
        if(data.meta.code == 200){
            get_notes();
        }
        else{
            var msg = "";
            $.each(data.meta.error_message,function(i,j){
                if(i == 0){
                    msg += j;   
                }
                else{
                    msg += ","+j; 
                }
            });
            alert(msg);
        }
    });
    post.error(function(data){
    //alert('Network Error');
    });
}

var note='';
$("#message").keyup(function(){
    var moco = $(this);
    var note = moco.val();
    console.log(note);
    add_notes();
});

function details_notes(id){
    var token =window.localStorage.getItem('token');
    var before =$('#message').val("Loading data ...");
    var before =$('#note_title').val("Loading data ...");
    var notes = new majax('notes/detail',{'access_token':token,'note_id':id},before);
    note_det ='';
    $('.list_notes').css('background-color','#fff');
    $('._title').css('color','#000');
    $('._time').css('color','#ddd');

    $('#index_'+id).css('background-color','#62bdc3');
    $('#_title'+id).css('color','#fff');
    $('#_time'+id).css('color','#fff');

    notes.success(function(data){
       //console.log(data);
       //console.log(count);
    $.each(data.data,function(){
        var notes = data.data.Note;
        //console.log(notes);
        note_det=notes.note;
        $('#note_title').val(notes.title);
        ga_action('Notes','Open',notes.title);
        if(notes.note==null){
        $('#message').val(" ");
        }else{
        $('#message').val(notes.note);
        }
        setTimeout(function(){
            textAreaAdjust(document.getElementById('note_title'));
        },100)
        
    }); 
       });
        //window.localStorage.setItem('note_id',id)
        note_id = id;
}

var note='';
$("#message").keyup(function(){
    var moco = $(this);
    var note = moco.val();
    console.log(note);
    add_notes();
});

function edit_notes(){
    var token =window.localStorage.getItem('token');
    $('#message').keyup(function(){
        clearTimeout(typingTimer);
        if ($('#message').val()) {
            typingTimer = setTimeout(function(){
                //do stuff here e.g ajax call etc....
                var title = $("#note_title").val();
                var note= $('#message').val();
                //console.log(note);
                if (note_id==null){
                    console.log('kosong');
                }else{
                    var data={'access_token':token,'title':title,'note_id':note_id,'note':note};
                    var post = majax_post('notes/edit',data,'');
                    post.success(function(data){
                    //console.log(data);
                    if(data.meta.code == 200){
                        get_notes();
                    }
                    else{
                        var msg = "";
                        $.each(data.meta.error_message,function(i,j){
                            if(i == 0){
                                msg += j;   
                            }
                            else{
                                msg += ","+j; 
                            }
                        });
                        alert(msg);
                    }
                });
                }
            }, doneTypingInterval);
        }
    });
}

function _set_notes(){
    var tot = $(window).height();
    var not = $('.max_height').width();
    var pad = tot-85;
    var _pad = pad/2;
    //console.log(tot,pad,_pad);
    $('#_lnotes').css('height',pad);
    $('#_dnotes').css('height',tot);
    console.log(not)
    $('#_line_notes').css('width',not);
}

function textAreaAdjust(o) {
    o.style.height = "1px";
    o.style.height = (o.scrollHeight)+"px";
}