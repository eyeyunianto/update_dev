function rec_detail (data) {
  $('#rec_detail').click();
  // console.log(item);
  // item.forEach(function(entry) {
  //   console.log(entry);
  // });
  var user=""; 
  var n = 0;
  var action = "";
  try {
    if(eval("rec_notif"+data)){
      var item = eval("rec_notif"+data)
      n = item.length;
      // console.log(item)
      $.each(item, function(index, value){
        if(index% 2 === 0){
          action=value
        }else{
          console.log(index,n,action,value)
          if(value== "null"){
            var name = "Moco User"
          }else{
            var name = value
          }
          if(n==2){
            user+='<span onclick="user_details('+action+')" style="cursor:pointer;">'+name+'</span>';
          }else if(n==4){
            if((index)==(n-1)){
              user+=" and ";
            }
            user+='<span onclick="user_details('+action+')" style="cursor:pointer;">'+name+'</span>';
          }else{
            if((index)==(n-1)){
              user+=" and ";
            }
            user+='<span onclick="user_details('+action+')" style="cursor:pointer;">'+name+'</span>';
            if(n>2){
              if((index)<(n-3)){
                user+=", ";
              }
            }
          }
        }
      });
    }
  } catch (e) {
      console.log(e.message);
  }
  
  notif_read(data);
  setTimeout(function() {
    $('#rec_ava').attr('src',eval("rec_dnotif"+data+"[1]")).attr('onclick','user_details('+eval("rec_dnotif"+data+"[0]")+')')
    $('#rec_title').html(eval("rec_dnotif"+data+"[5]"))
    $('#name_rec').html(eval("rec_dnotif"+data+"[2]"))
    $('#rec_msg').html(eval("rec_dnotif"+data+"[9]"))
    $('#rec_cov').attr('src',eval("rec_dnotif"+data+"[4]")).attr('onclick','books('+eval("rec_dnotif"+data+"[3]")+')')
    $('#rec_author').html(eval("rec_dnotif"+data+"[6]"))
    $('#rec_desc').html(eval("rec_dnotif"+data+"[7]").replace(/-/g,'.').replace(/\+/g,',').replace(/\*/g, ''))
    $('#rec_user').html(user)
    $('#rec_time').html(eval("rec_dnotif"+data+"[8]"))
    // .replace(/-/g,'.').replace(/--/g,',').replace(/\*/g, '<br>')
  },200)
}

function on_cat(){
  $( "#_category_act" )
    .mouseenter(function() {
      // $('#library').addClass('aktif');
      $('.drop_menu').show();
      $('#main_layout').css('padding-left','320px')
    })
    .mouseleave(function() {
      // $('#library').removeClass('aktif');
      $('.drop_menu').hide();
      $('#main_layout').css('padding-left','117px')
    });
}

function off_cat(){
  $( "#_category_act" )
    .mouseenter(function() {
      //$('#library').addClass('aktif');
      $('.drop_menu').hide();
    })
    .mouseleave(function() {
      //$('#library').removeClass('aktif');
      $('.drop_menu').hide();
    });
}

function cat_open(){
  // $('.drop_menu').show();
  // $('#over_cat').addClass('overlay2');
  // $('#main_layout').css('padding-left','320px')
  // $( "#_category_act" ).attr('onclick','cat_close()').css('color','#fff').css('background-color','#888').css('border','transparent')
  // $('.col-md-2').removeClass('col-xs-3').removeClass('col-md-2').addClass('col-xs-6').addClass('col-md-4');
  // $('#search_result').hide();
  // $('#book-category').css('width','100%');
  // $('#result').hide();
  // $('#scroll_lib').css("width","100%");
  // $('.dash').css('left','350px').css('padding-left','0');
  // $('.navbar-right').removeClass('col-xs-6').removeClass('col-md-4')
}

function cat_close(){
  // $('.drop_menu').hide();
  // $('#over_cat').removeClass('overlay2');
  // $('#main_layout').css('padding-left','117px');
  // $( "#_category_act" ).attr('onclick','cat_open()').css('color','#fff').css('background-color','transparent').css('border','1px solid #fff')
  // $('.col-md-4').removeClass('col-xs-6').removeClass('col-md-4').addClass('col-xs-3').addClass('col-md-2');
  // $('.nav').removeClass('col-xs-3').removeClass('col-md-2').addClass('col-xs-6').addClass('col-md-4');
  // $('.dash').css('left','0').css('padding-left','117px');
  // $('.navbar-right').removeClass('col-xs-6').removeClass('col-md-4')
}


function action_cat(){
  $("#_category_act").click(function(e){
    $('#_close').click();
    $('.drop_menu').removeClass('fadeOutLeft').addClass('fadeInLeft')
    // $(".drop_menu").show();
    // $('#over_cat').addClass('overlay2');
    // $('#search_dropdown').hide();
    // $("#_category_act").attr('onclick','cat_close()')
    e.stopPropagation();
    setTimeout(function(){
      $(".drop_menu").show();
      $('#over_cat').addClass('overlay2');
      $('#search_dropdown').hide();
      $("#_category_act").attr('onclick','cat_close()')
      $("#_category_deac").show();
      $("#_category_act").hide();
    },800)
    // dea_toogle();
  });

  $(".drop_menu").click(function(e){
      e.stopPropagation();
  });

  $(document).click(function(){
    $('.drop_menu').removeClass('fadeInLeft').addClass('fadeOutLeft')
    setTimeout(function(){
      $(".drop_menu").hide();
      $('#over_cat').removeClass('overlay2');
      $("#_category_act").show();
      $("#_category_deac").hide();
    },800)
      // act_toogle();
  });

  $("#over_cat").click(function(e){
    $('.drop_menu').removeClass('fadeInLeft').addClass('fadeOutLeft')
    setTimeout(function(){
      $(".drop_menu").hide();
      $('#over_cat').removeClass('overlay2');
      $("#_category_act").show();
      $("#_category_deac").hide();
    },800)
    // act_toogle();
  });
  $("#query_search").click(function(e){
    $('.drop_menu').removeClass('fadeInLeft').addClass('fadeOutLeft')
    setTimeout(function(){
      $(".drop_menu").hide();
      $('#over_cat').removeClass('overlay2');
      $("#_category_act").show();
      $("#_category_deac").hide();
    },800)
    // act_toogle();
  });
  $("#_category_deac").click(function(e){
    $('.drop_menu').removeClass('fadeInLeft').addClass('fadeOutLeft')
    setTimeout(function(){
      $(".drop_menu").hide();
      $('#over_cat').removeClass('overlay2');
      $("#_category_act").show();
      $("#_category_deac").hide();
    },800)
    // act_toogle();
  });
}



// function book_toogledown(){
//   genre_toogledown();
//   $('.li_book').show();
//   $('#list_books').css('display','block');
//   $('#toogle_book').attr('onclick','book_toogleup()')
//   $('#toogle_book').removeClass('fa-angle-down').addClass('fa-angle-up');
// }

// function book_toogleup(){
//   genre_toogleup();
//   $('.li_book').hide();
//   $('#list_books').css('display','block');
//   $('#toogle_book').attr('onclick','book_toogledown()')
//   $('#toogle_book').removeClass('fa-angle-up').addClass('fa-angle-down');
// }

function genre_toogledown(){
  $('.li_genre').show().removeClass('fadeOutUp').addClass('fadeInDown');;
  $('#toogle_genre').attr('onclick','genre_toogleup()')
  $('#toogle_genre i').removeClass('fa-angle-right').addClass('fa-angle-down');
}

function genre_toogleup(){
  $('.li_genre').removeClass('fadeInDown').addClass('fadeOutUp');
  setTimeout(function(){
    $('.li_genre').hide()
    $('#toogle_genre').attr('onclick','genre_toogledown()')
    $('#toogle_genre i').removeClass('fa-angle-down').addClass('fa-angle-right');
  },700)
}

var r_book,c_r_book;
function books_reading(id){
  r_book = 0;
  c_r_book =2;
  $('#r_more').css('visibility','visibility:hidden');
  local = ReadData('_books_reading'+id);
  if(local!=null){
    p_books_reading(local);
  }
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_reading').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  // var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  var check = new majax_fast('books/reading',{'client_id':client_id,'book_id':id,'per_page':20},before);
  check.error(function(data) {
      $('#r_reading').html('');
      $('#tot_reading').html('0');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_reading').html('');
      $('#r_action_more').attr('onclick','m_books_reading('+id+')');
      $('#lr_reading').html('');
      $('#tot_reading').html(data.data.total_result);
      r_book = data.data.num_pages;
      WriteData('_books_reading'+id,data);
      p_books_reading(data);
      if(data.data.num_pages>1){
        $('#r_more').css('visibility','visible');
      }else{
        $('#r_more').css('visibility','hidden');
      }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#lr_reading').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      $('#tot_reading').html('0');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_reading').html(book);
      // },1000)
      $('#r_more').css('visibility','hidden');
      //console.log('empty')
      //console.log(book);
    }
  });
}
function p_books_reading(data){
  var book='';
  $.each(data.data.data,function(){
    var User =this;
    if(User.avatar==null || User.avatar==""){
      image="images/icon/avatar.png";
    }else{
      image=User.avatar;
    }
    book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
    <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
    </div>'});
  $('#lr_reading').html(book);
  setTimeout(function(){
    $('#lr_reading .col-md-1 .media-object').popover();
     preload_ava('.media-object')
  },500);
}
function m_books_reading(id){
  if(c_r_book <= r_book){
    $('#r_more').css('visibility','visibility:hidden');
    var book='';
    var token =window.localStorage.getItem('token');
    var image;
    var before=  $('#r-moco-load').addClass('fa fa-spinner fa-spin fa-large');
    // var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
    var check = new majax_fast('books/reading',{'client_id':client_id,'book_id':id,'per_page':20,'page':c_r_book},before);
    check.error(function(data) {
        // $('#r_reading').html('');
         $('#r-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
    }),
    check.success(function(data){
      c_r_book++;
      $('#r-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
      if(data.meta.code==200){
        $.each(data.data.data,function(){
          var User =this;
          if(User.avatar==null || User.avatar==""){
            image="images/icon/avatar.png";
          }else{
            image=User.avatar;
          }
          book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
          <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle ava" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
          </div>'});
        $('#lr_reading').append(book);
        setTimeout(function(){
          $('#lr_reading .col-md-1 .media-object').popover();
          preload_ava('.ava');
        },500);
        if(data.data.current_page_result>=20){
          $('#r_more').css('visibility','visible');
        }else{
          $('#r_more').css('visibility','hidden');
        }
        //console.log(book);
      }else{
        book=data.meta.error_message;
        // $('#lr_reading').append('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
        $('#r_more').css('visibility','hidden');
        //console.log('empty')
        //console.log(book);
      }
    });
  }else{
    // $('#lr_reading').append('<center style="color:#ddd;padding-top:50px;"></center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
    $('#r_more').css('visibility','hidden');
  }
}

var h_book,c_h_book;
function books_has_read(id){
  h_book = 0;
  c_h_book =2;
  $('#h_more').css('visibility','visibility:hidden');
  local = ReadData('_books_has_read'+id);
  if(local!=null){
    p_books_has_read(local);
  }
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_has_read').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  // var check = new majax('items/user_has_read_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  var check = new majax_fast('books/has_reading',{'client_id':client_id,'book_id':id,'per_page':20},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#tot_has_read').html('0');
      $('#lr_has_read').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_has_read').html('');
      $('#h_action_more').attr('onclick','m_books_has_read('+id+')');
      $('#lr_has_read').html('');
      $('#tot_has_read').html(data.data.total_result);
      //shelf_book = data.data.num_pages;
      h_book = data.data.num_pages;
      WriteData('_books_has_read'+id,data);
      p_books_has_read(data);
      if(data.data.num_pages>1){
        $('#h_more').css('visibility','visible');
      }else{
        $('#h_more').css('visibility','hidden');
      }
      console.log(book);
    }else{
      book=data.meta.error_message;
      $('#tot_reading').html('0');
      $('#lr_has_read').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_has_read').html(book);
      // },1000)
      $('#h_more').css('visibility','hidden');
    }
  });
}
function p_books_has_read(data){
  var book='';
  $.each(data.data.data,function(){
    var User =this;
    if(User.avatar==null || User.avatar==""){
      image="images/icon/avatar.png";
    }else{
      image=User.avatar;
    }
    book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
    <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
    </div>'});
  $('#lr_has_read').html(book);
  setTimeout(function(){
    $('#lr_has_read .col-md-1 .media-object').popover();
    preload_ava('.media-object')
  },500);
}
function m_books_has_read(id){
  if(c_h_book <= h_book){
    $('#h_more').css('visibility','visibility:hidden');
    var book='';
    var token =window.localStorage.getItem('token');
    var image;
    var before=  $('#h-moco-load').addClass('fa fa-spinner fa-spin fa-large');
    // var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
    var check = new majax_fast('books/has_reading',{'client_id':client_id,'book_id':id,'per_page':20,'page':c_h_book},before);
    check.error(function(data) {
        // $('#r_reading').html('');
         $('#h-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
    }),
    check.success(function(data){
      c_r_book++;
      $('#h-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
      if(data.meta.code==200){
        // $('#lr_has_read').html('');
        // $('#h_action_more').attr('onclick','m_books_reading('+id+')');
        // $('#lr_has_read').html('');
        // h_book = data.data.num_pages;
        // p_books_has_read(data);
        $.each(data.data.data,function(){
          var User =this;
          if(User.avatar==null || User.avatar==""){
            image="images/icon/avatar.png";
          }else{
            image=User.avatar;
          }
          book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
          <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle ava" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
          </div>'});
        $('#lr_has_read').append(book);
        setTimeout(function(){
          $('#lr_has_read .col-md-1 .media-object').popover();
          preload_ava('.media-object')
        },500);
        if(data.data.current_page_result>=20){
          $('#h_more').css('visibility','visible');
        }else{
          $('#h_more').css('visibility','hidden');
        }
        //console.log(book);
      }else{
        book=data.meta.error_message;
        // $('#lr_has_read').append('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
        $('#h_more').css('visibility','hidden');
        //console.log('empty')
        //console.log(book);
      }
    });
  }else{
    // $('#lr_has_read').append('<center style="color:#ddd;padding-top:50px;"></center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
    $('#h_more').css('visibility','hidden');
  }
}

var w_book,c_w_book;
function books_wants(id){
  w_book = 0;
  c_w_book =2;
  $('#w_more').css('visibility','visibility:hidden');
  local = ReadData('_books_wants'+id);
  if(local!=null){
    p_books_wants(local);
  }
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_wants').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  // var check = new majax('wishlists/user_want_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  var check = new majax_fast('books/want',{'client_id':client_id,'book_id':id,'per_page':20},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_wants').html('');
      $('#tot_reading').html('0');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_wants').html('');
      $('#w_action_more').attr('onclick','m_books_wants('+id+')');
      $('#lr_wants').html('');
      $('#tot_wants').html(data.data.total_result);
      w_book = data.data.num_pages;
      WriteData('_books_wants'+id,data);
      p_books_wants(data);
      //shelf_book = data.data.num_pages;
      if(data.data.num_pages>1){
        $('#w_more').css('visibility','visible');
      }else{
        $('#w_more').css('visibility','hidden');
      }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#tot_reading').html('0');
      //console.log(book);
      $('#lr_wants').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_wants').html(book);
      // },1000)
      $('#w_more').css('visibility','hidden');
    }
  });
}
function p_books_wants(data){
  var book='';
  $.each(data.data.data,function(){
    var User =this;
    if(User.avatar==null || User.avatar==""){
      image="images/icon/avatar.png";
    }else{
      image=User.avatar;
    }
    book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
    <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
    </div>'});
  $('#lr_wants').html(book);
  setTimeout(function(){
    $('#lr_wants .col-md-1 .media-object').popover();
    preload_ava('.media-object')
  },500);
}
function m_books_wants(id){
  if(c_w_book <= w_book){
    $('#w_more').css('visibility','visibility:hidden');
    var book='';
    var token =window.localStorage.getItem('token');
    var image;
    var before=  $('#w-moco-load').addClass('fa fa-spinner fa-spin fa-large');
    // var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
    var check = new majax_fast('books/want',{'client_id':client_id,'book_id':id,'per_page':20,'page':c_w_book},before);
    check.error(function(data) {
        // $('#r_reading').html('');
         $('#w-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
    }),
    check.success(function(data){
      c_w_book++;
      $('#w-moco-load').removeClass('fa fa-spinner fa-spin fa-large');
      if(data.meta.code==200){
        // $('#lr_has_read').html('');
        // $('#w_action_more').attr('onclick','m_books_wants('+id+')');
        // $('#lr_has_read').html('');
        // w_book = data.data.num_pages;
        // p_books_wants(data);
        $.each(data.data.data,function(){
          var User =this;
          if(User.avatar==null || User.avatar==""){
            image="images/icon/avatar.png";
          }else{
            image=User.avatar;
          }
          book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
          <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle ava" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
          </div>'});
        $('#lr_wants').append(book);
        setTimeout(function(){
          $('#lr_wants .col-md-1 .media-object').popover();
           preload_ava('.media-object')
        },500);
        if(data.data.current_page_result>=20){
          $('#w_more').css('visibility','visible');
        }else{
          $('#w_more').css('visibility','hidden');
        }
        //console.log(book);
      }else{
        book=data.meta.error_message;
        // $('#lr_wants').append('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
        $('#w_more').css('visibility','hidden');
        //console.log('empty')
        //console.log(book);
      }
    });
  }else{
    // $('#lr_wants').append('<center style="color:#ddd;padding-top:50px;"></center>');
        // setTimeout(function(){
        //   book=data.meta.error_message;
        //   $('#lr_reading').html(book);
        // },1000)
    $('#w_more').css('visibility','hidden');
  }
}

function promo_login(){
  var token = window.localStorage.getItem('token');
  var check = new majax('users/after_login_popup',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(data);
      Moco.content=data.data; 
      $('#_promo').click();
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
}
function promo_couchmark(){
  var token = window.localStorage.getItem('token');
  var check = new majax('users/after_coachmark_popup',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(data);
      Moco.content=data.data; 
      $('#_promo').click();
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
}
function promo_release(){
  var token = window.localStorage.getItem('token');
  var login = window.localStorage.getItem('_login');
  console.log(login);
  if(login){
  }else{
    var check = new majax('books/release_popup',{'client_id':client_id},'');
    check.success(function(data){
      localStorage.setItem('_login',true)
      console.log(data)
      if(data.meta.code==200){
        var book = data.data.Book;
        var promotion = data.data.Promotion;
        var author = data.data.Authors;
        //console.log(data);
        // Moco.content=data.data; 
        // $('#_promo').click();
        Moco.image= book.cover
        Moco.link='books('+book.id+')'
        Moco.title=limitCharacter(book.title,12)
        Moco.author=limitCharacter(book.authors,12)
        var synopsis = book.synopsis;
        var description = removeHtml(book.description);
        if(synopsis){
          Moco.synopsis = limitCharacter(synopsis,150)
        }else if(book.description){
          Moco.synopsis = limitCharacter(description,150);
        }else{
          Moco.synopsis = 'No Description';
        }
      $('#release').click();
      }else{
        // Moco.content=data.meta.error_message;
        // $('#confirm_trans_failed').click();
      }
    });
    check.error(function(data){
      console.log(data)
    })
  }
}

// - After Login Popup
// http://webstore.aksaramaya.com/apis/users/after_login_popup?access_token=xdqJLzp05hQaIYwhMrqqRJnQpCGWXQYJuES6593w

// - After Coachmark Popup
// http://webstore.aksaramaya.com/apis/users/after_coachmark_popup?access_token=xdqJLzp05hQaIYwhMrqqRJnQpCGWXQYJuES6593w

// - Detail Book Popup before Get Book (ada di Object Promotion->value)
// http://webstore.aksaramaya.com/apis/books/detail?book_id=1015&client_id=NTEwMzg4M2IxYjdjM2M3

