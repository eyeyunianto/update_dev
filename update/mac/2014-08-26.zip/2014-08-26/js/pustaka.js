function pustaka(id){
  window.location.href="index.html#/main";
  setTimeout(function(){
    window.location.href="#/main/details/pustaka/"+id+"/";
    setTimeout(function(){
      pustaka_cov(id);
      history.push('pustaka('+id+')');
    },500);
  },500);
}

var library_id;
var library_cost;
var like_type;
var comments_type;
var follow_type;
var pustaka_desc;
var pustaka_name;
function pustaka_cov(id){
  ads_data=[];
  follow_type='library';
  status_pustaka=0;
  var book='';
  var book2='';
  var book3='';
  var rate='';
  pustaka_desc='';
  var token =window.localStorage.getItem('token');
  var check = new majax('libraries/detail',{'access_token':token,'library_id':id},'');

  check.success(function(data){
    if(data.meta.code==200){
      like_type=2;
      comments_type="Library";
      follow_type="Library";
      //console.log(data);
      var Config = data.data.Config;
      var Library = data.data.Library;
      var University = data.data.University;
      var Statistic = data.data.Statistic;
      var S_pop = data.data.Sponsors.popup_purchase;
      var S_read = data.data.Sponsors.in_reader;

      pustaka_name = Library.name;

      ga_pages('/library/'+Library.name,Library.name);

      if(S_pop.length!=0){
        S_pop.forEach(function(item){
          var sponsor = item.Sponsor;
          console.log(sponsor);
          ads_data[0]=sponsor.banner;
          var link = sponsor.url.split('http://');
          if(link[0]==sponsor.url){
            ads_data[1]='http://'+sponsor.url;
          }else{
            ads_data[1]=sponsor.url;
          }
        });
      }else{

      }

      library_id = id;
      follow_data=Library.id;
      library_cost = Config["Library.MembershipCharge"]/1000;
      pustaka_link = Library.url_profile;
      //library_cost =100;
      //$('#back').attr('onclick','epustaka_tab()');
      
      //back history
      // var back = history[history.length-2];
      // $('#back_history').attr('onclick',back);

      book+='<div><span class="black medium" style="font-size:20px;line-height:1">'+Library.name+'</span></div>\
        <div class="black" style="font-size:14px;line-height:1;padding-top:3px;">'+Statistic.total_books+' Books <span style="margin-left:10px;margin-right:10px;border-left:1px solid #444; width:2px;"></span> '+Library.address+'</div>';
        //<div class="grey" style="font-size:14px;line-height:1;padding-top:10px;">'+Library.address+'</div>';

      $('#pustaka_cover').html('<img src="'+Library.logo+'" style="width:127px;height:127px;border-radius:3px;background-color:#fff;border:1px solid #ddd">');
      $('#pustaka_property').html(book);

      // book2+='<div class="grey">'+Library.about+'</div>';
      // $('#about').html(book2);

      $('#dropdown_recommend').css('display','none');
      $('#border_recommend').css('display','none');

      //WIN
      // $('#facebook').attr('onclick','javascript:ign.desktopService("http://www.facebook.com/sharer.php?u='+pustaka_link+'")');
      // $('#twitter').attr('onclick','javascript:ign.desktopService("http://twitter.com/share?text=Reading with Moco Hybrid&url='+pustaka_link+'")');
      // $('#google').attr('onclick','javascript:ign.desktopService("https://plus.google.com/share?url='+pustaka_link+'")');
      // $('#email').attr('onclick','javascript:ign.desktopService("mailto:?Subject=Recommended to Join &Body=I%20saw%20a%20great%20pustaka%20on%20Moco!%20%20Please%20Click%20On%20 '+pustaka_link+'")');
      // $('#linkedin').attr('onclick','javascript:ign.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+pustaka_link+'")');

      //MAC
      // $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+pustaka_link+'&picture='+Library.logo+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0")');
      // $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text=Reading with Moco Hybrid&url='+pustaka_link+'")');
      // $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url='+pustaka_link+'")');
      // $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Join &Body=I%20saw%20a%20great%20pustaka%20on%20Moco!%20%20Please%20Click%20On%20 '+pustaka_link+'")');
      // $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+pustaka_link+'")');

      $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+pustaka_link+'&picture='+Library.logo+'&name='+Library.name+'&description='+Statistic.total_books+' books '+Library.address+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0")');
      $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text='+Library.name+' on moco%20%0Avia moco desktop%20%0A&url='+pustaka_link+'")');
      $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url='+pustaka_link+'")');
      $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Follow&Body='+Library.name+'%20%0A'+Statistic.total_books+' books '+Library.address+'%20%0A'+pustaka_link+'%20%0Avia moco desktop")');
      $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+pustaka_link+'")');

      book3+='<ul class="nav nav-tabs" id="pustaka_scroll"style="font-size:16px;background-color:#f4f1f1" >\
        <li class="on" id="nav_books_books" style="width:13%;font-size:16px;"><a onclick="nav_books(5)" style="margin-right:0px;border-left:0px;"><div class="medium" style="line-height:1;padding-top:10px;">'+Statistic.total_books+'</div><div style="line-height:1">books</div></a></li>\
        <li class="of" id="nav_books_followers" style="width:13%;font-size:16px;"><a onclick="nav_books(6)" style="margin-right:0px;border-left:0px;"><div class="medium" style="line-height:1;padding-top:10px;">'+Statistic.total_followers+'</div><div  style="line-height:1">followers</div></a></li>\
        <li class="of" id="nav_books_comments" style="width:13%;font-size:16px;"><a onclick="nav_books(4)" style="margin-right:0px;border-left:0px;"><div class="medium" id="tot_comments" style="line-height:1;padding-top:10px;">'+Statistic.total_comments+'</div><div  style="line-height:1">comments</div></a></li>\
        <li class="of" id="nav_sponsored" style="width:61%;visibility:hidden;"><a onclick="load_sponsored()" style="cursor:pointer"><div id="sponsored_image" class="black" style="padding-top:13px;">This e-Pustaka sponsored by<span style="float:right"><i class="fa fa-chevron-right grey"style="padding-right:20px;font-size:23px;"></i></span></div></a></li>\
      </ul><div class="col-md-12  result" id="r_books" style="padding-bottom: 50px;background-color:#fff"><div class="col-md-12"><div class="col-xs-4 col-md-2" style="padding-top:15px;"><div class="dropdown">\
        <span class="dropdown-toggle" style="cursor:pointer" data-toggle="dropdown" ><span id="text-categories">Recommended</span><i class="fa fa-angle-down" style="padding-left:10px;"></i></span>\
        <ul class="dropdown-menu">\
          <li><a class="text-center" style="cursor:pointer" onclick="epus_books_rec()">Recommended</a></li>\
          <li><div class="divider" style="padding-top:0px"></div></li>\
          <li><a class="text-center" style="cursor:pointer" onclick="epus_cat()">Categories</a></li>\
        </ul>\
      </div></div>\
      <div class="col-xs-8 col-md-10">\
      <div id="searchContainer">\
          <div class="input-group" style="padding:5px;">\
            <input type="text" style="border-right-color:transparent;" class="form-control" id="e_query_search" placeholder="Search our library...">\
            <span class="input-group-addon" style="background-color:#fff;border-left-color:transparent;"><i class="fa fa-search" style="color:#c92036;"></i></span>\
          </div>\
        </div>\
      </div>\
      </div>\
      <div id="detail_book" style=""></div>\
      <div class="" style="cursor:pointer;height:30px;visibility:hidden;padding-top:15px;margin-bottom:50px;height:100%" id="e_more">\
      <center><button id="e_action_more" class="btn btn_rounded" onclick="epustaka_books_more()" style="">\
       Load More </button></center>\
      </div> \
      </div>\
      <div class="col-md-12 result" id="r_followers" style="padding: 0px;padding-left:30px;padding-top:30px;display:none;"></div>\
      <div class="col-md-12 result" id="r_comments" style="padding: 0px;overflow:hidden;display:none;padding-bottom:50px;"><div id="lr_comments" style="background-color:#fff;padding-bottom:70px;"></div>\
        <div class="" style="z-index:1;cursor:pointer;height:30px;visibility:hidden;padding-top:15px;margin-bottom:90px;background-color:#fff" id="load_more_comment">\
        <center style="background-color:#fff"><button id="comment_action" class="btn btn_rounded" onclick="more_feed()" style="color:#888;margin-bottom:15px;margin-top:15px;"> Load More </button></center>\
        </div>\
      </div>';
      $('.pustaka_det').html(book3);
      //console.log(book);
      // <div class="row" id="e_more" style="top:50px;visibility:hidden;padding-bottom:20px;padding-left:30px;"><h3><span id="e_action_more" onclick="epustaka_books_more()" style="color:#000;cursor:pointer"><i class="" id="load-more"></i> More... <i class="fa fa-angle-double-right"></i></span></h3></div></div>\
     
      _load_();

      pustaka_desc+='<div class="media col-md-12" style="padding-left:0px;">\
      <div class="col-xs-2 col-md-2" style="">\
        <img src="'+Library.logo+'" style="width:50px;height:50px;">\
      </div>\
      <div class="col-xs-10 col-md-10">\
        <div></div>\
        <div class="medium" style="font-size:20px;line-height:1">'+Library.name+'</div>\
        <div><span class="grey" style="font-size:14px;line-height:1">'+data.data.Statistic.total_books+' Books</span></div>\
      </div>\
      </div>\
      <div style="padding-top:10px;"><h3 class="black" style="font-size:18px">About</h3><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(Library.about)+'</p></div>';
      

      $('#read_more').hide();
      book2=desc_more(Library.about);
      $('#about').html(book2);
      setTimeout(function(){
        //epustaka_follower();
        general_follow();
        epustaka_books();
        check_member();
        p_comments_detail(Library.id);
        p_sponsor();
        check_follow(id);
        det_scroll("#scroll_det","#pustaka_scroll",308,"40px");
      },2000);
    }else{
      book=data.meta.error_message;
      $('.pustaka_cov').html('<div class="black">'+book+'</div>');

    }
  });
}

function load_sponsored(){
  $('#_epus_col').click();
  var book3;
  setTimeout(function(){
    book3="";
    $('#follow_content').text("");
    $('.modalDialog').css('padding','5px 0px 10px');
    book3 +='<a onclick="change_pic(1)" style="cursor:pointer"><div class="media col-md-12 sidebar-text" style="padding-left:10px;margin-top:10px;margin-bottom:10px;">\
              <div class="col-md-1" style=";padding-left:0px;"></div>\
              <div class="col-md-10" style=";padding-left:0px;">\
                <img class="media-object" src="images/icon/unilever.png" style="height:35px;">\
              </div>\
              </div></a>\
              <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
    book3 +='<a onclick="change_pic(2)" style="cursor:pointer"><div class="media col-md-12 sidebar-text" style="padding-left:10px;margin-top:10px;margin-bottom:10px;">\
              <div class="col-md-1" style=";padding-left:0px;"></div>\
              <div class="col-md-10" style=";padding-left:0px;">\
                <img class="media-object" src="images/icon/medco-icn.png" style="height:35px;">\
              </div>\
              </div></a>\
              <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
    book3 +='<a onclick="change_pic(3)" style="cursor:pointer"><div class="media col-md-12 sidebar-text" style="padding-left:10px;margin-top:10px;margin-bottom:10px;">\
              <div class="col-md-1" style=";padding-left:0px;"></div>\
              <div class="col-md-10" style=";padding-left:0px;">\
                <img class="media-object" src="images/icon/icn-mandiri.png" style="height:35px;">\
              </div>\
              </div></a>\
              <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';

    $('#follow_content').html(book3);
    setModalSize();
    $('.modalDialog').css('padding','5px 0px 10px');
    $('#follow').html("Sponsored");
    $('#follow_content').contents()[0].nodeValue = '';
  },300);
}

function _load_(){
  if(JSON.parse(localStorage.getItem(user_id+'_sponsor'))==undefined || JSON.parse(localStorage.getItem(user_id+'_sponsor'))==null){
    sponsor_list=[];
  }else{
    sponsor_list = JSON.parse(localStorage.getItem(user_id+'_sponsor'));
  }
}

var sponsor_list;
var sponsor_id;
var sponsor_index;
var sponsor_pic;
function change_pic(data){
  check_sponsor(library_id);
  if(sponsor_id!=library_id){
    add_sponsor(data);
  }else{
    edit_sponsor(data,sponsor_index);
  }
  if(data==1){
    $('#sponsored_image').html('<div class="col-md-12" style=";padding-left:0px;cursor:pointer">\
        <div class="col-xs-5 col-md-5"></div>\
        <div class="col-xs-3 col-md-3">\
        <img class="media-object" src="images/icon/unilever.png" style="height:25px;">\
        </div>\
      </div>');
  }else if(data==2){
    $('#sponsored_image').html('<div class="col-md-12" style=";padding-left:0px;cursor:pointer">\
        <div class="col-xs-4 col-md-4"></div>\
        <div class="col-xs-3 col-md-3">\
        <img class="media-object" src="images/icon/medco-icn.png" style="height:25px;">\
        </div>\
      </div>');
  }else if(data==3){
    $('#sponsored_image').html('<div class="col-md-12" style=";padding-left:0px;cursor:pointer;">\
        <div class="col-xs-5 col-md-5"></div>\
        <div class="col-xs-3 col-md-3">\
        <img class="media-object" src="images/icon/icn-mandiri.png" style="height:25px;">\
        </div>\
      </div>');
  }
}

function add_sponsor(data){
  sponsor_list.push({"lib_id":library_id,"picture":data});
  localStorage.setItem(user_id+'_sponsor', JSON.stringify(sponsor_list));
}

function edit_sponsor(data,index){
  sponsor_list[index]={"lib_id":library_id,"picture":data};
  localStorage.setItem(user_id+'_sponsor', JSON.stringify(sponsor_list));
}

function check_sponsor(data){
  if(sponsor_list!=undefined){
    i=0;
    sponsor_list.forEach(function(){
      var _sponsor = sponsor_list[i].lib_id;
      console.log(_sponsor);
      if(_sponsor==data){
        sponsor_index = i ;
        sponsor_pic = sponsor_list[i].picture;
        sponsor_id = _sponsor;
      }else{
        sponsor_index=undefined;
      }
      i++
    });
  }
}

function p_sponsor(){
  check_sponsor(library_id);
  if(sponsor_id==library_id){
    change_pic(sponsor_pic);
  }
}

var page_pustaka=0;
var c_page_pustaka =2;
function epustaka_books(){
  var book='';
  c_page_pustaka=2;
  page_pustaka =0;
  $('#e_more').css('visibility','hidden');
  var before=setTimeout(function(){
    $('#detail_book').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var token =window.localStorage.getItem('token');
    var check = new majax('books/epustaka_collections',{'access_token':token,'library_ids':'['+library_id+']','per_page':12},before);
    check.success(function(data){
      if(data.meta.code==200){
        $('#detail_book').html('');
        $('#e_action_more').attr('onclick','epustaka_books_more()');
        $.each(data.data.data,function(){
          //console.log(data);
          if(data.data!=undefined){
            page_pustaka = data.data.num_pages;
          }
          var Book=this.Book;
          var Badge=this.Badge;
          var _author;
          if(Book.authors==""){
            _author = "-";
          }else{
            _author = limitCharacter(Book.authors,12);
          }
          book+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
            <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="font-size:12px;">'+_author+'</div>\
          </div></div>'});
        $('#detail_book').html(book+'</div>');
        if(data.data!=undefined){
          if(data.data.num_pages>1){
            $('#e_more').css('visibility','visible');
            console.log('show')
          }else{
            $('#e_more').css('visibility','hidden');
          }
        }
        setTimeout(function(){
          e_search_books();
        },500);
        //console.log(book);
      }else{
        //$('#detail_book').html('');
        book=data.meta.error_message;
        $('#detail_book').html(book);
        $('#e_more').css('visibility','hidden');
      }
      if(data.meta.confirm==null){
        book=data.meta.error_message;
        $('#detail_book').html('<center class="grey">Data not found</center>');
        $('#e_more').css('visibility','hidden');
      }
    });
}
function epustaka_books_more(){
  if(c_page_pustaka <= page_pustaka){
    var book='';
    // var before=setTimeout(function(){
    //   $('#detail_book').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    // },100);
    var token =window.localStorage.getItem('token');
    var check = new majax('books/epustaka_collections',{'access_token':token,'library_ids':'['+library_id+']','per_page':12,'page':c_page_pustaka},'');
    check.success(function(data){
      c_page_pustaka ++;
      if(data.data.current_page_result<12){
        $('#e_more').css('visibility','hidden');
      }
      if(data.meta.code==200){
        $.each(data.data.data,function(){
          //console.log(data);
          //page_pustaka = data.data.num_pages;
          var Book=this.Book;
          var Badge=this.Badge;
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
            <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="font-size:12px;">'+_author+'</div>\
          </div></div>'});
        $('#detail_book').append(book+'</div>');
        setTimeout(function(){
          e_search_books();
        },500);
        //console.log(book);
      }else{
        book=data.meta.error_message;
        $('#detail_book').append(book);

      }
    });
  }else{
    $('#e_more').css('visibility','hidden');
  } 
}

function epus_books_cat(cat){
  var book='';
  c_page_pustaka=2;
  page_pustaka =0;
  $('#e_more').css('visibility','hidden');
  var before=setTimeout(function(){
    $('#detail_book').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var token =window.localStorage.getItem('token');
  var check = new majax('books/browse_collections',{'access_token':token,'library_ids':'['+library_id+']','category_ids':'['+cat+']','per_page':10},before);
  check.success(function(data){
    if(data.meta.code==200){
      if(data.data!=undefined){
        page_pustaka = data.data.num_pages;
      }
      $('#detail_book').html('');
      $('#e_action_more').css('onclick','more_epus_books_cat('+cat+')');
      $.each(data.data.data,function(){
        //console.log(data);
        var Book=this.Book;
        var Badge=this.Badge;
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
            <div class="light-blue" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="font-size:12px;">'+_author+'</div>\
          </div></div>'});
      $('#detail_book').html(book);
      if(data.data!=undefined){
        if(data.data.num_pages>1){
          $('#e_more').css('visibility','visible');
        }else{
          $('#e_more').css('visibility','hidden');
        }
      }
      //console.log(book);
    }else{
      book+=data.meta.error_message;
      $('#detail_book').html(book);
      $('#e_more').css('visibility','hidden');
    }
  });
}

function more_epus_books_cat(cat){
  if(c_page_pustaka <= page_pustaka){
    var book='';
    // var before=setTimeout(function(){
    //   $('#detail_book').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    // },100);
    var token =window.localStorage.getItem('token');
    var check = new majax('books/browse_collections',{'access_token':token,'library_ids':'['+library_id+']','category_ids':'['+cat+']','per_page':10,'page':c_page_pustaka},'');
    check.success(function(data){
      if(data.meta.code==200){
        if(data.data.current_page_result<12){
            $('#e_more').css('visibility','hidden');
           }
        c_page_pustaka ++;
        $.each(data.data.data,function(){
          //console.log(data);
          var Book=this.Book;
          var Badge=this.Badge;
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
              <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
              <div class="light-blue" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
              <div class="grey" style="font-size:12px;">'+_author+'</div>\
            </div></div>'});
        $('#detail_book').html(book);
        //console.log(book);
      }else{
        book+=data.meta.error_message;
        $('#detail_book').html(book);
        $('e_more').css('visibility','hidden')
      }
    });
  }
}


function epus_books_rec(){
  var book='';
  var before=setTimeout(function(){
    $('#detail_book').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var token =window.localStorage.getItem('token');
  var check = new majax('books/recommended_collections',{'access_token':token,'library_ids':'['+library_id+']','per_page':1010},before);
  check.success(function(data){
    if(data.meta.code==200){
      $('#detail_book').html('');
      $.each(data.data.data,function(){
        //console.log(data);
        var Book=this.Book;
        var Badge=this.Badge;
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
            <div class="light-blue" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="font-size:12px;">'+_author+'</div>\
          </div></div>'});
      $('#detail_book').html(book);
      //console.log(book);
    }else{
      book+=data.meta.error_message;
      $('detail_book').html(book);

    }
  });
}

function e_books_categories(){
  // catHtml=undefined;
  $('#follow_content').html('');
  var book='';
  var before=setTimeout(function(){
    $('.modalDialog').css('background-color','#f4f1f1');
    $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  if(catHtml!=undefined){
    setTimeout(function(){
      var catNew = catHtml.replace(/books_cat/g,'e_books_cat');
      $('#follow_content').html(catNew);
     // $('#follow_content').css('position','fixed').css('left','32.5%').css('top','17%').css('height','490px').css('overflow-y','auto').css('width','35%');
      $('#follow').html("Categories");
      $('.modalDialog').css('padding','5px 0px 10px');
    },500);
  }else{
    var check = new majax('categories/index',{'client_id':client_id},before);
    book+='<div class="cat" onclick="e_books_cat()" style="cursor:pointer">\
          <div style="border-bottom:1px solid #ddd;border-top:1px solid #ddd;padding:5px;color:#c92036"><span class="text-cat" id="text-">All Categories</span>\
          <span class="fa2 fa fa-check moco-red" id="icn-" style="float:right;"></span></div>\
          </div>';
    check.error(function(data) {
      //alert('Network Problem');
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click();
      $('#follow_content').html('');
      $('.modalDialog').css('padding','5px 0px 10px');
    }),
    check.success(function(data){
      if(data.meta.code==200){
        $('#follow_content').html('');
        $.each(data.data,function(){
          //console.log(data);
          var Category = this.Category;
          var Childs = this.Childs;
          //console.log(data);
          book+='<div class="cat" onclick="e_books_cat('+Category.id+')" style="cursor:pointer">\
          <div style="border-bottom:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-'+Category.id+'">'+Category.name+'</span>\
          <span class="fa2 fa fa-check moco-red" id="icn-'+Category.id+'" style="float:right;visibility:hidden;"></span></div>\
          </div>';
          //console.log(Childs);
          /*if(Childs!=undefined){
            $.each(Childs,function(){
              var Child = this.Category; 
              book+='<div class="cat" onclick="e_books_cat('+Child.id+','+Child.parent_id+')" style="cursor:pointer">\
              <div style="border-bottom:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-'+Child.id+'" style="padding-left:20px;">'+Child.name+'</span>\
              <span class="fa2 fa fa-check moco-red" id="icn-'+Child.id+'" style="float:right;visibility:hidden;"></span></div>\
              </div>'});
            }*/
          });
        $('#follow_content').html(book);
        catHtml=book;
        //$('#follow_content').css('position','fixed').css('left','32.5%').css('top','17%').css('height','490px').css('overflow-y','auto').css('width','35%');
        $('#follow').html("Categories");
        $('.modalDialog').css('padding','5px 0px 10px');
      }else{
        book=data.meta.error_message;
        $('#follow_content').html(book);
      }
    });
  }
}

function e_books_cat(data,cat){
  //console.log(data);
  $('.fa2').css('visibility','hidden');
  $('.text-cat').css('color','#282828');

  $('#text-categories').html('Categories');
  
  if(cat!=undefined){
    $('#text-'+data).css('color','#c92036');
    $('#text-'+cat).css('color','#c92036');
    $('#icn-'+data).css('visibility','visible');
  }else if(data!=undefined){
    $('#icn-'+data).css('visibility','visible');
    $('#text-'+data).css('color','#c92036');
    //$('#text-categories').html('Recommended');
  }else{
    //$('.fa2').css('visibility','hidden');
    $('#icn-').css('visibility','visible');
    //$('.text-cat').css('color','#282828');
    $('#text-').css('color','#c92036');
  }
  //$('#text-categories').html(data);
  epus_books_cat(data);
}

function epus_cat(){
  $('#_epus_col').click();
  setTimeout(function(){
    e_books_categories();
  },500);
}

function books_pustaka(id){
  setTimeout(function(){
    window.location.href="#/main/details/books/"+id+"/";
    setTimeout(function(){
      books_cov(id,undefined,'pustaka');
      // overview(id);
      check_collection(id);
      setTimeout(function(){
        $('#epustaka').css('display','none');
        $('#btn-getbooks').removeAttr('data-ember-action');
        $('#btn-getbooks').attr('onclick','check_member_epustaka('+library_id+',2)');
      },1000);
    },500);
  },500); 
}

var list_p,c_list_p;
function index_library(){
  history.push('epus_click()');
  list_p=0;
  c_list_p=2;
  $('#elist_more').css('visibility','hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var local = ReadData('_pustaka');
    if(local!=null){
      //console.log(local);
      parse_pustaka(local);
    }else{
      var before=setTimeout(function(){
        $('#list_epustaka').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
      },100);
    }
  var check = new majax('libraries/index',{'client_id':client_id,'per_page':12},'');
  check.error(function(data) {
      //alert('Network Problem');
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click();
      //$('#list_epustaka').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      WriteData('_pustaka', data)
      if(local==null){
        //console.log(local);
        parse_pustaka(data);
      }
      //console.log(book);
    }else{
      $('#elist_more').css('visibility','hidden');
    }
  });
}

function d_pustaka(id,name){
  var nama = name.replace(/_/g,' ')
  ga_action('Library','Choose Library',nama);
  pustaka(id);
}

function parse_pustaka(data){
  $('#list_epustaka').html('');
  var book='';
  $.each(data.data,function(){
    //console.log(data);
    if(data.data!=undefined){
      list_p=data.data.num_pages;
      if(data.data.num_pages>1){
        $('#elist_more').css('visibility','visible');
      }else{
        $('#elist_more').css('visibility','hidden');
      }
    }
    
    var Book = this.Book;
    var Library = this.Library;
    var Statistic = this.Statistic;
    //console.log(data);
    book+='<div class="col-xs-3 col-md-2 _pus" style="padding-bottom:30px;"><center>\
      <div style="height:135px"><a href="#/main/moco/library/"';
    book+="onclick=d_pustaka("+Library.id+",'"+Library.name.replace(/ /g,'_')+"')>";
    book+='<img class="lib_" src="'+Library.logo+'" style="height:126px;width:126px;border:1px solid #ddd;border-radius:5px;"></a></div></center>\
      <div class="light-blue pus_" style="font-size:14px;">'+limitCharacter(Library.name,12)+'</div>\
      <div class="grey pus_" style="font-size:12px;">'+Statistic.total_books+' Books</div>\
    </div>'});
  $('#list_epustaka').html(book);
  preload_img('.lib_');
  set_pust();
  if($('#scroll_lib').attr('data-split')=="true"){
    split_lib();
  }else{
    merge_lib();
    setTimeout(function(){
      search_books();
    },500);
  }
}
function set_pust(){
  var tot = $('._pus').width();
  var pad = tot-125;
  var _pad = pad/2;
  //console.log(tot,pad,_pad);
  $('.pus_').css('padding-left',_pad);
}
$(window).on('resize', function(){
  // var win = $(this); //this = window
  // if (win.height() >= 820) { /* ... */ }
  // if (win.width() >= 1280) { /* ... */ }
  set_pust();
  set_want();
  _set_notes();
});

function moreindex_library(){
  if(c_list_p<=list_p){
    var book='';
    var token =window.localStorage.getItem('token');
    // var before=setTimeout(function(){
    //   $('#list_epustaka').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    // },100);
    var check = new majax('libraries/index',{'client_id':client_id,'per_page':12,'page':c_list_p},'');
    check.error(function(data) {
        //alert('Network Problem');
        Moco.content="No Internet Connection";
        $('#confirm_trans_failed').click();
        //$('#list_epustaka').html('');
        $('#elist_more').css('visibility','hidden');
    }),
    check.success(function(data){
      if(data.meta.code==200){
        $.each(data.data,function(){
          //console.log(data);
          var Book = this.Book;
          var Library = this.Library;
          var Statistic = this.Statistic;
          //console.log(data);
          book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;"><center>\
          <div style="height:135px"><a href="#/main/moco/library/" onclick="pustaka('+Library.id+')"><img class="" src="'+Library.logo+'" style="height:126px;width:126px;border:1px solid #ddd;border-radius:5px;"></a></div></center>\
          <div class="light-blue" style="font-size:14px;">'+limitCharacter(Library.name,12)+'</div>\
          <div class="grey" style="font-size:12px;">'+Statistic.total_books+' Books</div>\
        </div>'});
        $('#list_epustaka').html(book);
        if(data.data.num_pages>1){
          $('#elist_more').css('visibility','visible');
        }
        setTimeout(function(){
          search_books();
        },500);
        //console.log(book);
      }else{
        $('#elist_more').css('visibility','hidden');
      }
    });
  }else{
    $('#elist_more').css('visibility','hidden');
  }
}

function about_pustaka_det(){
  setTimeout(function(){
    $('#follow_content').html(pustaka_desc);
    $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  },500)
  // var book='';
  // var token =window.localStorage.getItem('token');
  // var id =window.localStorage.getItem('id');
  // var before=setTimeout(function(){
  //   $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  // },100);
  // //alert(books_id);
  // var check = new majax('Libraries/detail',{'access_token':token,'library_id':library_id},before);
  // check.error(function(data) {
  //     //alert('Network Problem');
  //     Moco.content="No Internet Connection";
  //     $('#confirm_trans_failed').click();
  //     $('#follow_content').html('');
  //     }),
  // check.success(function(data){
  //   if(data.meta.code==200){
  //     var Library = data.data.Library;

  //     book+='<div class="media col-md-12" style="padding-left:0px;">\
  //     <div class="col-md-1" style="width:40px;height:40px;overflow:hidden;border-radius:4px;">\
  //       <img src="'+Library.logo+'" style="width:80px;height:80px;">\
  //     </div>\
  //     <div class="col-md-11">\
  //       <div></div>\
  //       <div>'+Library.name+'</div>\
  //       <div><span class="grey">'+data.data.Statistic.total_books+' Books</span></div>\
  //     </div>\
  //     </div>\
  //     <div><h3 class="black">About</h3><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(library.about)+'</p></div>';
  //     $('#follow_content').html(book);
  //     $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  //     //data=data.data;
  //     //console.log(data);
  //     //$('#follow').html("Followers");
  //   }else{
  //     //$('#follow').html("Followers");
  //     $('#follow_content').html(data.meta.error_message);
  //   }
  // });
  // $('#follow_content').html(book);
}

function borrow_books_c(confirm){
  var token =window.localStorage.getItem('token');
  var data ={'access_token':token,'book_id':books_id,'library_id':library_id,'confirm':confirm};
  var post2 = majax_post('books/borrow_book',data,'');
  post2.success(function(data){
    //console.log(data);
    if(data.meta.code == 200){
        // $('#confirm_trans_success').click();
      Moco.content="Your book has been added to collection";
      $('#confirm_trans_success').click();
      setTimeout(function(){
        check_collection(books_id);
      },500)
    }
    else{
      //$('#confirm_trans_failed').click();
        var msg = "";
        // $.each(data.meta.error_message,function(i,j){
        //     if(i == 0){
        //         msg += j;   
        //     }
        //     else{
        //         msg += ","+j; 
        //     }
        // });
        //alert(msg);
        msg=data.meta.error_message;
        //$('#btn_trans').html('OK');
        //$('#message_warning').html(msg);
        check_collection(books_id);
    }
  });
}
function borrow_books(data,id_lib,name){
  if(data==undefined){
    $('#text_'+library_id).removeClass('fa-check').addClass('fa-spinner fa-spin');
  }
  if(name){
    ga_action('Library','Borrow From',name);
  }
  if(id_lib!=undefined){
    library_id = id_lib;
  }
  var token =window.localStorage.getItem('token');
    var data ={'access_token':token,'book_id':books_id,'library_id':library_id};
    var post = majax_post('books/borrow_book',data,'');
    post.success(function(data){
      //console.log(data);
      if(data.meta.code == 200){
        // Moco.content="Your book has been added to collection";
        // $('#confirm_trans_success').click();
        if(data!=undefined){
          is_expired(data);
        }
        check_collection(books_id);
      }else if(data.meta.code == 400){
        var msg = "";
          $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }
              else{
                  msg += ","+j; 
              }
          });
          //alert(msg);
          //msg=data.meta.error_message;
          if(data.meta.error_code=="request_confirm"){
             borrow_books_c(1); 
          }else{
            Moco.content=msg;
            $('#confirm_trans_failed').click();
            $('#btn_trans').html('OK');
            if(id_lib!=undefined){
              if(msg!="Your borrowing history has reached maximum quota"){
                borrow_books_c(1); 
              } 
            }
          }
          
      }else{
        
          var msg = "";
          // $.each(data.meta.error_message,function(i,j){
          //     if(i == 0){
          //         msg += j;   
          //     }
          //     else{
          //         msg += ","+j; 
          //     }
          // });
          //alert(msg);
          msg=data.meta.error_message;
          Moco.content=msg;
          setTimeout(function(){
            if(id_lib!=undefined){
              borrow_books_c(1);  
            }
          },200)
          
          // $('#confirm_trans_failed').click();
          // $('#btn_trans').html('OK');
      }
    });
}

function _join(){
    setTimeout(function(){
      $('.modalDialog').css('width','350px').css('height','450px').css('border-radius','6px').css('margin','12% auto');
      $('#points_join').html('<b>'+library_cost+'</b> Points');
    	$('#points_join').removeAttr('data-ember-action');
    	$('#points_join').attr('onclick','_join_pass()');
      check_password();
      if(status_pustaka==1){
        $('#close_pass').removeAttr('data-ember-action');
        $('#close_pass').attr('onclick','javascript:$("#_conf_join").click();');
      }
    },500);
}

function _join_pass(){
	$('#pass_trans').click();
	setTimeout(function(){
		$('#btn-final-trx').attr('onclick','join_regular()');
    $('#close_pass').removeAttr('data-ember-action');
    $('#close_pass').attr('onclick','join_click()');
    check_password();
	},500);
}

function join_click(){
  $('#join_pustaka').click();
}

function unix_member(){
    data="";
    var token = window.localStorage.getItem('token');
    var action = new majax_post('students/signup_member',{'access_token':token,'unique_code':confirm_password},'');
    action.success(function(data){
      //console.log(data);
        if(data.meta.code == 200){
            $('#_confirm_trans_success').click();
            setTimeout(function(){
              $('#welcome').html('Welcome, New Member!');
              $('#welcome').css('font-size','18px');
              $('#desc').html('We are delighted to have you!');
              ga_action('Library','Joined',pustaka_name,'free');
            	if(status_pustaka==1){
                borrow_books(1);
              }else{
                check_member();
              }
            },500);
        }
        else{
            //$('#confirm_trans_failed').click();
          	var msg = "";
          	// $.each(data.meta.error_message,function(i,j){
           //    if(i == 0){
           //        msg += j;   
           //    }
           //    else{
           //        msg += ","+j; 
           //    }
          	// });
            msg=data.meta.error_message;
          	//alert(msg);
          	Moco.content=msg;
            $('#confirm_trans_failed').click();
        }
    });
}

function join_regular(){
  data='';
	var token = window.localStorage.getItem('token');
  var before=$('#transaction_confirm').html('<center style="padding-top:20px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  	var req_data ={'access_token':token,'password':confirm_password,'library_id':library_id};
  	var post = majax_post('students/signup_regular',req_data,before);
  	post.success(function(data){
      console.log(data);
    	if(data.meta.code == 200){
      	$('#_confirm_trans_success').click();
        setTimeout(function(){
          $('.modalDialog').css('width','300px').css('height','300px').css('border-radius','6px').css('margin','15% auto');
          $('#welcome').html('Welcome, New Member!');
          $('#welcome').css('font-size','18px');
          $('#desc').html('We are delighted to have you!');

          ga_action('Library','Joined',pustaka_name,library_cost);

          if(status_pustaka==1){
            borrow_books(1);
          }else{
            check_member();
          }
        },500);
     	}else{
       		//$('#confirm_trans_failed').click();
			     var msg = "";
        	$.each(data.meta.error_message,function(i,j){
            	if(i == 0){
                	msg += j;   
            	}else{
                	msg += ","+j; 
            	}
          	});
          //alert(msg);
        	//$('#message_warning').html(msg);
          Moco.content=msg;
          $('#confirm_trans_failed').click();
      	}
  	});
}

function check_member(){
  var token = window.localStorage.getItem('token');
    var member = new majax('students/is_member',{'access_token':token,'library_id':library_id},"");
    member.success(function(data){
        //console.log(data);
    if(data.meta.code==200){
      if(data.data=='true'){
        $('#join_pustaka').css('background-color','#aaa');
        $('#join_pustaka').removeAttr('data-ember-action');
        $('#join_pustaka').css('padding','10px 10px');
        $('#join_text').html('You`re a Member');
        $('#join_pustaka').css('border','1px solid #888');
        $("#join_check").addClass('icon mc-check moco-white');
        $("#join_check").css('padding-right','10px');
        // $('#nav_sponsored').css('visibility','visible');
      }else{
        //is_free_epustaka();
      }
    }else{
          //alert("Server Response Timeout");
    }
  });
}

/*Logic Borrow*/
function confirm_join_pustaka(id){
  $('#_conf_join').click();
  setTimeout(function(){
    $('#close_join').css('display','none');
    $('#x_close_join').css('display','block');
    $('#join_pustaka').attr('data-ember-action','');
    $('#join_pustaka').attr('onclick','is_free_epustaka('+id+')');
    borrow_books();
  },500)
}


var borrow="";
function check_member_epustaka(id,state){
  var token = window.localStorage.getItem('token');
  var member = new majax('students/is_member',{'access_token':token,'library_id':id},"");
  //books_id = book;
  member.success(function(data){
        //console.log(data);
    if(data.meta.code==200){
      if(data.data=='true'){
        status_pustaka=1;
        is_expired(id);
        if(state==2){
          borrow_books();
        };
      }else{
          confirm_join_pustaka(id);
        //is_free_epustaka(id);
      }
    }else{
          //alert("Server Response Timeout");
    }
  });
}

function is_expired(lib_id){
  var token = window.localStorage.getItem('token');
  library_id=lib_id;
  // if(status_pustaka==1){
  //   borrow_books();
  // }
  var member = new majax('students/is_expired',{'access_token':token,'library_id':library_id},"");
  member.success(function(data){
        //console.log(data);
    if(data.meta.code==200){
      if(data.data=='true'){
        is_free_epustaka_extend();
      }else{
        borrow_books_c(1);
      }
    }else{
          //alert("Server Response Timeout");
    }
  });
}

function is_free_epustaka(id){
    var member = new majax('libraries/is_free_epustaka',{'client_id':client_id,'library_id':id},"");
    member.success(function(data){
        //console.log(data);
    if(data.meta.code==200){
      if(data.data=='true'){
        signup_member();
      }else{
        //signup_regular();
        $('#conf_trans').click();
        borrow="signup_regular()";
      }
    }else{
          //alert("Server Response Timeout");
    }
  });
}

function is_free_epustaka_extend(){
    var member = new majax('libraries/is_free_epustaka',{'client_id':client_id,'library_id':library_id},"");
    member.success(function(data){
        //console.log(data);
    if(data.meta.code==200){
      if(data.data=='true'){
        extend_bycode();
      }else{
        $('#conf_trans').click();
        borrow="extend_regular()";
      }
    }else{
          //alert("Server Response Timeout");
    }
  });
}

function _borrow(){
    setTimeout(function(){
        $('.modalDialog').css('width','300px').css('height','300px').css('border-radius','6px').css('margin','15% auto');
        var html='<center>\
          <p class="grey" style="font-size:20px">You`re going to spend :</p>\
          <p style="font-size:60px;line-height:1;margin-bottom:0;padding-top:10px;" class="medium" id="points_cost">'+library_cost+'</p>\
          <p class="grey" style="font-size:30px;margin-bottom:20px;">points</p>\
          <button class="btn btn-default" style="background-color: #1ebe8e;color:#fff;padding:10px 40px;border-radius:21px;" onclick="'+borrow+'">CONFIRM</button>\
          </center>';
        $('#cost_spend').html(html);
        check_password();
    },100);
}

function close_borrow(){
  $('#confirm_trans_success').click();
  setTimeout(function(){
    $('.x').click();
  },50);
}

function signup_member(){
  $('#pass_trans').click();
  setTimeout(function(){
    $('#pass_title').html("Enter Your Unique Code");
    $('#password_trx').attr('placeholder','Enter your unique Code here');
    $('#btn-final-trx').attr('onclick','unix_member()');
    $('#close_pass').removeAttr('data-ember-action');
    $('#close_pass').attr('onclick','close_borrow()');
    check_password();
  },500)
}

function signup_regular(){
  $('#pass_trans').click();
  setTimeout(function(){
    //$('#pass_title').html("Enter Your Unique Code");
    //$('#password_trx').attr('placeholder','Enter your unique Code here');
    $('#btn-final-trx').attr('onclick','join_regular()');
    $('#close_pass').removeAttr('data-ember-action');
    $('#close_pass').attr('onclick','close_borrow()');
  },500)
}

function extend_bycode(){
  $('#pass_trans').click();
  setTimeout(function(){
    $('#pass_title').html("Enter Your Unique Code");
    $('#password_trx').attr('placeholder','Enter your unique Code here');
    $('#btn-final-trx').attr('onclick','extend_member_bycode()');
    $('#close_pass').removeAttr('data-ember-action');
    $('#close_pass').attr('onclick','close_borrow()');
  },500)
}

function extend_regular(){
  $('#pass_trans').click();
  setTimeout(function(){
    //$('#pass_title').html("Enter Your Unique Code");
    //$('#password_trx').attr('placeholder','Enter your unique Code here');
    $('#btn-final-trx').attr('onclick','extend_member_regular()');
    $('#close_pass').removeAttr('data-ember-action');
    $('#close_pass').attr('onclick','close_borrow()');
  },500)
}

function extend_member_regular(){
  var token = window.localStorage.getItem('token');
    var data ={'access_token':token,'password':confirm_password,'library_id':library_id};
    var post = majax_post('students/extend_regular',data,'');
    post.success(function(data){
      //console.log(data);
        if(data.meta.code == 200){
          if(status_pustaka==1){
            borrow_books(1);
          }else{
            $('#_confirm_trans_success').click();
            setTimeout(function(){
              $('#welcome').html('Success');
              $('#welcome').css('font-size','18px');
              $('#desc').html('We are delighted to have you!');
            },500);
          }
      }else{
          //$('#confirm_trans_failed').click();
      var msg = "";
          $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }else{
                  msg += ","+j; 
              }
            });
          //alert(msg);
          //$('#message_warning').html(msg);
          Moco.content=msg;
          $('#confirm_trans_failed').click();
        }
    });
}

function extend_member_bycode(){
    var token = window.localStorage.getItem('token');
    var action = new majax_post('students/extend_bycode',{'access_token':token,'unique_code':confirm_password},'');
    action.success(function(data){
        if(data.meta.code == 200){
          if(status_pustaka==1){
            borrow_books(1);
          }else{
            $('#_confirm_trans_success').click();
            setTimeout(function(){
              $('#welcome').html('Success');
              $('#welcome').css('font-size','18px');
              $('#desc').html('We are delighted to have you!');
            },500);
          }
        }else{
            //$('#confirm_trans_failed').click();
            var msg = "";
            $.each(data.meta.error_message,function(i,j){
              if(i == 0){
                  msg += j;   
              }
              else{
                  msg += ","+j; 
              }
            });
            //alert(msg);
            //$('#message_warning').html(msg);
            Moco.content=msg;
            $('#confirm_trans_failed').click();
        }
    });
}

var page_search,count_search;
var moco_query;
function e_search_books(){
  page_search=0;
  count_search=2;
  $("input#e_query_search").keyup(function(ex){
  //$("input#e_query_search").keyup(function(){
  var moco = $(this);
  moco_query = moco.val();
  var moco_lenght = moco_query.length;
  // if(moco_lenght > 1){
  //   $('#scroll_det').scrollTop(336);
  // }
  if(ex.keyCode == 13){
      clearTimeout(typingTimer);
      ga_action('Library Book','Search',moco_query);
      if ($('input#e_query_search').val) {
          typingTimer = setTimeout(function(){
              //window.location.href="index.html#/main/moco/search/"
              ga_pages('/library/search','Library Search Books');
              $.ajax({
                  type: 'GET',
                  url: realtime+':6161/search',
                  //url: 'http://store.aksaramaya.com:6161/search',
                  data: {'q':moco_query,'page':'1','per_pages':12,'library_id':library_id},
                  dataType:"json",
                  beforeSend:function(){
                      // $("#result").html("<center><h1 style='margin-top:25%'><i class='fa fa-spinner fa-spin fa-large'></i> Search...</h1></center>");
                      // //$("input#query_search").prop('disabled',true);
                      $("input#e_query_search").attr('disabled',true);
                  },
                  success: function(result){
                  $('#e_more').css('visibility','hidden');
                  var html = "";
                  if(result.meta.code == 200){
                    page_search = result.meta.total_pages;
                    $.each(result.data,function(){
                        var Book=this.Book;
                        var Category = this.Category;
                        var Publisher = this.Publisher;
                        var Statistic = this.Statistic;
                        //console.log(Book);
                        var _author;
                        if(Book.authors){
                          _author = limitCharacter(Book.authors,12)
                        }else{
                          _author='-';
                        }
                        html+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;"><center>\
                            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div></center>\
                            <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
                            <div class="grey" style="font-size:12px;">'+_author+'</div>\
                          </div></div>'});
                      $("#detail_book").html(html);
                      //resp_side();
                      $("input#e_query_search").prop('disabled',false);
                      if(result.meta.total_pages>1){
                            console.log('show')
                          $('#e_more').css('visibility','visible');
                        }else{
                          $('#e_more').css('visibility','hidden');
                        }
                        //resp_side();
                        $("input#query_search").prop('disabled',false);
                      /*
                      if(result.data.total_result < 20){
                          var more = false;
                      }
                      else{
                          var more = true;   
                      }    */        
                   }else{
                    $("#detail_book").html(result.meta.msg);
                    $("input#e_query_search").prop('disabled',false);
                   }
                }
              });
          }, doneTypingInterval);
      }
    // }else if(moco_lenght == 0) {
    //   //epustaka_books();
    //   $("input#e_query_search").prop('disabled',false);
    }else{
      //$("#detail_book").html("");
      $("input#e_query_search").prop('disabled',false);
        //recommended()
    }
  });
}

function moree_search_books(){
    if(count_search<=page_search){
        $.ajax({
            type: 'GET',
            url: realtime+':6161/search',
            //url: 'http://store.aksaramaya.com:6161/search',
            data: {'q':moco_query,'page':'1','per_pages':count_search,'library_id':library_id,'page':count_search},
            dataType:"json",
            beforeSend:function(){
                // $("#result").html("<center><h1 style='margin-top:25%'><i class='fa fa-spinner fa-spin fa-large'></i> Search...</h1></center>");
                // //$("input#query_search").prop('disabled',true);
                // $("input#query_search").attr('disabled',true);
            },
            success: function(result){
                count_search++;
            //$("#result").html("");
            var html = "";
            if(result.meta.code == 200){
                $.each(result.data,function(){
                    var Book=this.Book;
                    var Category = this.Category;
                    var Publisher = this.Publisher;
                    var Statistic = this.Statistic;
                    //console.log(Book);
                    var _author;
                    if(Book.authors){
                      _author = limitCharacter(Book.authors,12)
                    }else{
                      _author='-';
                    }
                    html+='<div class="aku"><div class="col-xs-3 col-md-2" style="padding-bottom:30px;"><center>\
                            <div style="height:192px"><a href="#/main/moco/library/" onclick="books_pustaka('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div></center>\
                            <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
                            <div class="grey" style="font-size:12px;">'+_author+'</div>\
                          </div></div>'});
                html += "<div class='result-load' active='false'></div>";
                $("#detail_book").append(html);
                //resp_side();
                $("input#query_search").prop('disabled',false);
                /*
                if(result.data.total_result < 20){
                    var more = false;
                }
                else{
                    var more = true;   
                }    */        
               }else{
                //$("#result").html(result.meta.msg);
                $("input#query_search").prop('disabled',false);
                $('#search_more').css('visibility','hidden');
               }
            }
        });
    }else{
        //$("#result").append("");
        $('#search_more').css('visibility','hidden');
    }
}